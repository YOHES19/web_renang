<?php
session_start();

// Cek apakah user adalah admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Ambil daftar pengguna dengan role 'dasar'
$users = $conn->query("SELECT id, nama FROM users WHERE role = 'dasar' ORDER BY nama ASC");

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $jumlah = $_POST['jumlah'];
    $status = $_POST['status'];

    // Validasi input
    if (empty($user_id) || empty($tanggal) || empty($jumlah) || empty($status)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        // Simpan ke database
        $stmt = $conn->prepare("INSERT INTO pembayaran2 (user_id, tanggal, jumlah, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isds", $user_id, $tanggal, $jumlah, $status);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Pembayaran berhasil ditambahkan!";
            header('Location: pembayaran_dasar.php');
            exit();
        } else {
            $error = "Gagal menambahkan pembayaran.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 15px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
        }

        .btn-submit {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            font-weight: bold;
            border-radius: 8px;
            padding: 8px;
        }

        .btn-submit:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
        }

        .btn-back {
            background: #6c757d;
            color: white;
            font-weight: bold;
            border-radius: 8px;
            padding: 8px;
        }

        .btn-back:hover {
            background: #5a6268;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">➕ Tambah Pembayaran</div>

        <?php if (isset($error)) : ?>
            <div class="alert alert-danger"><?= $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="mb-3">
                <label for="user_id" class="form-label">Nama Pengguna</label>
                <select name="user_id" id="user_id" class="form-control" required>
                    <option value="">-- Pilih Nama --</option>
                    <?php while ($user = $users->fetch_assoc()) : ?>
                        <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['nama']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Pembayaran</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah Pembayaran (Rp)</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="status" class="form-label">Status Pembayaran</label>
                <select name="status" id="status" class="form-control" required>
                    <option value="">-- Pilih Status --</option>
                    <option value="Lunas">Lunas</option>
                    <option value="Belum Lunas">Belum Lunas</option>
                </select>
            </div>

            <button type="submit" class="btn btn-submit w-100">Simpan Pembayaran</button>
            <a href="../pembayaran_dasar/pembayaran_dasar.php" class="btn btn-back w-100 mt-2">⬅ Kembali</a>
        </form>
    </div>

</body>

</html>

<?php
$conn->close();
?>