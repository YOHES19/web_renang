<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';
include '../../../models/pelatih.php';

$errors = [];
$success = "";

// Memastikan ID pelatih ada
if (!isset($_GET['id'])) {
    header('Location: kelola_pelatih.php');
    exit();
}

$pelatih_id = $_GET['id'];
$pelatih = getPelatihById($pelatih_id); // Mendapatkan data pelatih berdasarkan ID

if (!$pelatih) {
    header('Location: kelola_pelatih.php');
    exit();
}

// Jika form dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $spesialisasi = trim($_POST['spesialisasi']);
    $kontak = trim($_POST['kontak']);

    // Validasi form
    if (empty($nama)) {
        $errors[] = "Nama pelatih wajib diisi.";
    }
    if (empty($spesialisasi)) {
        $errors[] = "Spesialisasi wajib diisi.";
    }
    if (empty($kontak)) {
        $errors[] = "Kontak wajib diisi.";
    }

    // Jika tidak ada error, update ke database
    if (empty($errors)) {
        if (updatePelatih($pelatih_id, $nama, $spesialisasi, $kontak)) {
            $success = "Pelatih berhasil diupdate.";
        } else {
            $errors[] = "Gagal mengupdate pelatih.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelatih</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styling untuk card dan form */
        body {
            background: linear-gradient(to right, rgb(253, 255, 159), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        .card-custom {
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card-header-custom {
            background-color: #007bff;
            color: white;
            border-radius: 15px 15px 0 0;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .alert-custom {
            border-radius: 10px;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="container py-5">
        <div class="card card-custom">
            <div class="card-header card-header-custom">
                <h1 class="mb-0">Edit Pelatih</h1>
            </div>
            <div class="card-body">
                <?php if (!empty($errors)) : ?>
                    <div class="alert alert-danger alert-custom">
                        <ul>
                            <?php foreach ($errors as $error) : ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($success) : ?>
                    <div class="alert alert-success alert-custom"><?= htmlspecialchars($success) ?></div>
                <?php endif; ?>

                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Pelatih</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="<?= htmlspecialchars($pelatih['nama']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="spesialisasi" class="form-label">Spesialisasi</label>
                        <input type="text" name="spesialisasi" id="spesialisasi" class="form-control" value="<?= htmlspecialchars($pelatih['spesialisasi']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="kontak" class="form-label">Kontak</label>
                        <input type="text" name="kontak" id="kontak" class="form-control" value="<?= htmlspecialchars($pelatih['kontak']) ?>" required>
                    </div>

                    <button type="submit" class="btn btn-custom w-100">Simpan</button>
                    <a href="kelola_pelatih.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>