<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';
include '../../../models/pelatih.php';

// Memastikan ID pelatih ada
if (!isset($_GET['id'])) {
    header('Location: kelola_pelatih.php');
    exit();
}

$pelatih_id = $_GET['id'];

// Menghapus pelatih
if (deletePelatih($pelatih_id)) {
    header('Location: kelola_pelatih.php');
    exit();
} else {
    echo "Gagal menghapus pelatih.";
    exit();
}
