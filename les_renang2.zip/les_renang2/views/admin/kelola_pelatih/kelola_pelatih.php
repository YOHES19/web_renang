<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../models/pelatih.php';
$pelatihList = getAllPelatih();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pelatih - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styling untuk table dan tombol */
        .table th,
        .table td {
            vertical-align: middle;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
        }

        .btn-custom:hover {
            background-color: #0056b3;
            color: white;
        }

        .card-custom {
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card-header-custom {
            background-color: #007bff;
            color: white;
            border-radius: 15px 15px 0 0;
        }

        .table-custom {
            border-radius: 15px;
            overflow: hidden;
            border: none;
        }

        /* Background Gradien */
        body {
            background: linear-gradient(to right, rgb(253, 255, 159), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        /* Menyelaraskan tombol */
        .btn-group-custom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container py-5">
        <div class="card card-custom">
            <div class="card-header card-header-custom">
                <h1 class="mb-0">Kelola Pelatih</h1>
            </div>
            <div class="card-body">
                <div class="btn-group-custom">
                    <a href="tambah_pelatih.php" class="btn btn-custom mb-3">Tambah Pelatih</a>
                    <a href="../dashboard.php" class="btn btn-secondary mb-3">Kembali ke Dashboard</a>
                </div>
                <table class="table table-striped table-bordered table-hover table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Spesialisasi</th>
                            <th>Kontak</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($pelatihList as $pelatih) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($pelatih['nama']) ?></td>
                                <td><?= htmlspecialchars($pelatih['spesialisasi']) ?></td>
                                <td><?= htmlspecialchars($pelatih['kontak']) ?></td>
                                <td>
                                    <a href="edit_pelatih.php?id=<?= $pelatih['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="hapus_pelatih.php?id=<?= $pelatih['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus pelatih ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>