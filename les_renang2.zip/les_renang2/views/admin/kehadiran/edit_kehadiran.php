<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Mendapatkan ID dari URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Jika ID tidak ada, arahkan kembali ke laporan
if ($id == null) {
    header('Location: laporan_kehadiran.php');
    exit();
}

// Query untuk mengambil data kehadiran berdasarkan ID
$query = "SELECT kehadiran.id, kehadiran.status, kehadiran.tanggal 
          FROM kehadiran 
          WHERE kehadiran.id = '$id'";
$result = mysqli_query($conn, $query);

// Menangani jika data tidak ditemukan
if (mysqli_num_rows($result) == 0) {
    die("Data tidak ditemukan.");
}

// Ambil data kehadiran untuk ditampilkan di form
$row = mysqli_fetch_assoc($result);
$current_status = $row['status']; // Status kehadiran saat ini
$current_date = $row['tanggal']; // Tanggal kehadiran saat ini

// Proses update data ketika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_status = $_POST['status']; // Status yang baru
    $new_date = $_POST['tanggal']; // Tanggal yang baru

    // Update data kehadiran
    $update_query = "UPDATE kehadiran SET status = '$new_status', tanggal = '$new_date' WHERE id = '$id'";
    if (mysqli_query($conn, $update_query)) {
        header('Location: laporan_kehadiran.php'); // Redirect ke laporan setelah berhasil update
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kehadiran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, rgb(77, 247, 196), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e73df;
            color: white;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }

        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2e59d9;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Card untuk form edit kehadiran -->
        <div class="card">
            <div class="card-header">
                <h3>Edit Kehadiran</h3>
            </div>
            <div class="card-body">
                <!-- Form untuk edit kehadiran -->
                <form method="POST">
                    <div class="mb-3">
                        <label for="status" class="form-label">Status Kehadiran</label>
                        <select class="form-select" name="status" id="status" required>
                            <option value="Hadir" <?= $current_status == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                            <option value="Absen" <?= $current_status == 'Absen' ? 'selected' : '' ?>>Absen</option>
                            <option value="Izin" <?= $current_status == 'Izin' ? 'selected' : '' ?>>Izin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                        <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $current_date ?>" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Update Kehadiran</button>
                    </div>
                    <a href="laporan_kehadiran.php" class="btn btn-secondary mt-3 w-100">Kembali ke Laporan</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>

</html>