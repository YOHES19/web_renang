<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Query untuk mengambil data kehadiran
$query = "SELECT kehadiran.id, users.username, kehadiran.tanggal, kehadiran.status 
          FROM kehadiran 
          JOIN users ON kehadiran.user_id = users.id";  // Menyertakan nama user berdasarkan user_id
$result = mysqli_query($conn, $query);

// Menangani jika terjadi error pada query
if (!$result) {
    die("Query gagal: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kehadiran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(77, 247, 196), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .container {
            max-width: 1000px;
            margin-top: 50px;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e73df;
            color: white;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }

        .table th,
        .table td {
            text-align: center;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2e59d9;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }

        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
        }

        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #e0a800;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
            border-color: #c82333;
        }

        /* Menambahkan style untuk tombol Kembali */
        .btn-back {
            float: right;
        }

        .btn-save-pdf {
            margin-left: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Card Header -->
        <div class="card">
            <div class="card-header">
                <h3>Laporan Kehadiran</h3>
            </div>
            <div class="card-body">
                <!-- Tombol Kembali ke Dashboard yang terletak di kanan atas -->
                <a href="../dashboard.php" class="btn btn-secondary btn-back">Kembali ke Dashboard</a>

                <!-- Tombol untuk menambah kehadiran dan tombol save PDF yang berada di sampingnya -->
                <div class="d-flex mb-3">
                    <a href="tambah_kehadiran.php" class="btn btn-primary">Tambah Kehadiran</a>
                    <button id="download-pdf" class="btn btn-primary btn-save-pdf">Save as PDF</button>
                </div>

                <!-- Tabel Laporan Kehadiran -->
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Siswa</th>
                            <th>Tanggal Kehadiran</th>
                            <th>Status Kehadiran</th>
                            <th>Aksi</th> <!-- Menambahkan kolom aksi -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($row['username']) ?></td>
                                <td><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td><?= htmlspecialchars($row['status']) ?></td>
                                <td>
                                    <!-- Tombol Edit -->
                                    <a href="edit_kehadiran.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <!-- Tombol Hapus -->
                                    <a href="hapus_kehadiran.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <!-- Script untuk generate PDF -->
    <script>
        document.getElementById('download-pdf').addEventListener('click', function() {
            const {
                jsPDF
            } = window.jspdf;
            const doc = new jsPDF();

            // Menambahkan judul
            doc.setFontSize(18);
            doc.text('Laporan Kehadiran', 14, 20);

            // Menambahkan kolom header
            doc.setFontSize(12);
            doc.text('No', 14, 30);
            doc.text('Nama Siswa', 30, 30);
            doc.text('Tanggal Kehadiran', 90, 30);
            doc.text('Status Kehadiran', 150, 30);

            // Menambahkan data dari tabel
            let y = 40;
            let no = 1;
            const rows = document.querySelectorAll('.table-striped tbody tr');
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                doc.text(no.toString(), 14, y);
                doc.text(cells[1].innerText, 30, y);
                doc.text(cells[2].innerText, 90, y);
                doc.text(cells[3].innerText, 150, y);
                y += 10;
                no++;
            });

            // Menyimpan PDF
            doc.save('laporan_kehadiran.pdf');
        });
    </script>
</body>

</html>