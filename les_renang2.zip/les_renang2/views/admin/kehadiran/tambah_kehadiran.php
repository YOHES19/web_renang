<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Ambil data user dengan role 'user' atau 'selam' untuk dropdown
$query_user = "SELECT id, username, role FROM users WHERE role = 'user' OR role = 'selam'";
$result_user = mysqli_query($conn, $query_user);

// Proses untuk menambahkan kehadiran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $status = $_POST['status'];

    // Query untuk menyimpan data kehadiran
    $query_insert = "INSERT INTO kehadiran (user_id, tanggal, status) 
                     VALUES ('$user_id', '$tanggal', '$status')";

    if (mysqli_query($conn, $query_insert)) {
        echo "<script>alert('Data kehadiran berhasil ditambahkan!'); window.location.href='laporan_kehadiran.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data kehadiran: " . mysqli_error($conn) . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kehadiran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, rgb(77, 247, 196), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e73df;
            color: white;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
        }

        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }

        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2e59d9;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }

        .form-select,
        .form-control {
            border-radius: 8px;
        }

        .d-grid .btn {
            border-radius: 8px;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Card untuk form tambah kehadiran -->
        <div class="card">
            <div class="card-header">
                <h3>Tambah Kehadiran</h3>
            </div>
            <div class="card-body">
                <!-- Form untuk tambah kehadiran -->
                <form action="tambah_kehadiran.php" method="POST">
                    <div class="mb-3">
                        <label for="user_id" class="form-label">Nama Siswa</label>
                        <select class="form-select" id="user_id" name="user_id" required>
                            <option value="">Pilih Siswa</option>
                            <?php while ($row_user = mysqli_fetch_assoc($result_user)) { ?>
                                <option value="<?= $row_user['id'] ?>">
                                    <?= $row_user['username'] ?> (<?= $row_user['role'] ?>)
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status Kehadiran</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="Hadir">Hadir</option>
                            <option value="Tidak Hadir">Tidak Hadir</option>
                            <option value="Sakit">Sakit</option>
                            <option value="Izin">Izin</option>
                        </select>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Tambah Kehadiran</button>
                    </div>
                    <a href="laporan_kehadiran.php" class="btn btn-secondary mt-3 w-100">Kembali</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>

</html>