<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Fungsi untuk mendapatkan data waktu pretes dengan pagination
function getWaktuPretes($conn, $limit, $offset)
{
    $sql = "SELECT wp.*, u.nama as user_nama 
            FROM waktu_pretes wp
            JOIN users u ON wp.user_id = u.id
            ORDER BY wp.tanggal DESC 
            LIMIT $limit OFFSET $offset";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Fungsi untuk menghitung jumlah total data
function countWaktuPretes($conn)
{
    $sql = "SELECT COUNT(*) as total FROM waktu_pretes";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}

// Menentukan jumlah data per halaman
$limit = 5;

// Menentukan halaman saat ini
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Ambil data waktu pretes sesuai dengan pagination
$waktu_pretes = getWaktuPretes($conn, $limit, $offset);

// Hitung total data
$total = countWaktuPretes($conn);

// Hitung jumlah total halaman
$total_pages = ceil($total / $limit);

// Ambil daftar pengguna untuk dropdown
function getUsers($conn)
{
    $sql = "SELECT id, nama FROM users";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}
$users = getUsers($conn);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pretes - Les Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(to right, #f7c2f7, rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .card-header {
            background-color: #007bff;
            color: white;
        }

        .card-body {
            background-color: rgb(248, 250, 250);
        }

        .table th,
        .table td {
            text-align: center;
            vertical-align: middle;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-success i {
            margin-right: 8px;
        }

        .btn-danger i {
            margin-right: 8px;
        }

        .pagination {
            justify-content: center;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <a href="../dashboard.php" class="btn btn-secondary mb-4">Kembali ke Dashboard</a>

        <!-- Form Tambah Pretes -->
        <div class="card">
            <div class="card-header text-center">
                <h4>Tambah Data Pretes</h4>
            </div>
            <div class="card-body">
                <form action="proses_tambah_pretes.php" method="POST">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="user_id" class="form-label">Nama Peserta</label>
                            <select class="form-select" name="user_id" required>
                                <option value="">Pilih Nama</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>"><?= $user['nama'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="tanggal" class="form-label">Tanggal</label>
                            <input type="date" class="form-control" name="tanggal" required>
                        </div>
                        <div class="col-md-4">
                            <label for="waktu" class="form-label">Waktu</label>
                            <input type="time" class="form-control" name="waktu" required>
                        </div>
                    </div>

                    <div class="row g-3 mt-2">
                        <div class="col-md-3">
                            <label for="waktu_gaya_dada" class="form-label">Gaya Dada</label>
                            <input type="text" class="form-control" name="waktu_gaya_dada" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label for="waktu_gaya_bebas" class="form-label">Gaya Bebas</label>
                            <input type="text" class="form-control" name="waktu_gaya_bebas" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label for="waktu_gaya_kupu_kupu" class="form-label">Gaya Kupu-Kupu</label>
                            <input type="text" class="form-control" name="waktu_gaya_kupu_kupu" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label for="waktu_gaya_punggung" class="form-label">Gaya Punggung</label>
                            <input type="text" class="form-control" name="waktu_gaya_punggung" placeholder="00:00:00" required>
                        </div>
                    </div>

                    <!-- Menempatkan tombol di tengah -->
                    <div class="d-flex justify-content-center mt-4">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-plus-lg"></i> Tambah Pretes
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <!-- End Form Tambah Pretes -->


        <!-- Tabel Hasil Pretes -->
        <div class="card mt-5">
            <div class="card-header text-center">
                <h4>Hasil Pretes</h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                            <th>Gaya Dada</th>
                            <th>Gaya Bebas</th>
                            <th>Gaya Kupu-Kupu</th>
                            <th>Gaya Punggung</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = $offset + 1;
                        foreach ($waktu_pretes as $row): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $row['user_nama'] ?></td>
                                <td><?= $row['tanggal'] ?></td>
                                <td><?= $row['waktu'] ?></td>
                                <td><?= $row['waktu_gaya_dada'] ?></td>
                                <td><?= $row['waktu_gaya_bebas'] ?></td>
                                <td><?= $row['waktu_gaya_kupu_kupu'] ?></td>
                                <td><?= $row['waktu_gaya_punggung'] ?></td>
                                <td>
                                    <a href="edit_pretes.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </a>
                                    <a href="hapus_pretes.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                        </li>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- End Tabel Hasil Pretes -->

    </div>
</body>

</html>