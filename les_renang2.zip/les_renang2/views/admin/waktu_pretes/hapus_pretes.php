<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Fungsi untuk menghapus data pretes berdasarkan ID
function hapusWaktuPretes($conn, $id)
{
    $sql = "DELETE FROM waktu_pretes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    return $stmt->execute();
}

if (isset($_GET['id'])) {
    $pretesId = $_GET['id'];

    // Menghapus data pretes dari database
    if (hapusWaktuPretes($conn, $pretesId)) {
        // Setelah berhasil menghapus, kembali ke halaman daftar pretes
        header('Location: waktu_pretes1.php');
        exit();
    } else {
        die("Gagal menghapus data pretes.");
    }
} else {
    die("ID pretes tidak ditemukan.");
}
