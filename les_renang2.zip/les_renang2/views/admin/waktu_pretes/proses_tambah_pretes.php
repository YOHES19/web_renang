<?php
session_start();
include '../../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $waktu = $_POST['waktu'];
    $waktu_gaya_dada = $_POST['waktu_gaya_dada'];
    $waktu_gaya_bebas = $_POST['waktu_gaya_bebas'];
    $waktu_gaya_kupu_kupu = $_POST['waktu_gaya_kupu_kupu'];
    $waktu_gaya_punggung = $_POST['waktu_gaya_punggung'];

    $sql = "INSERT INTO waktu_pretes (user_id, tanggal, waktu, waktu_gaya_dada, waktu_gaya_bebas, waktu_gaya_kupu_kupu, waktu_gaya_punggung) 
            VALUES ('$user_id', '$tanggal', '$waktu', '$waktu_gaya_dada', '$waktu_gaya_bebas', '$waktu_gaya_kupu_kupu', '$waktu_gaya_punggung')";

    if ($conn->query($sql) === TRUE) {
        header("Location: waktu_pretes1.php");
    } else {
        echo "Error: " . $conn->error;
    }
}
