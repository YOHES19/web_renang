<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Ambil ID absen dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Jika ID tidak valid
if ($id <= 0) {
    header('Location: absen_dasar.php');
    exit();
}

// Ambil data absen berdasarkan ID
$query = "SELECT k.id, u.username, k.tanggal, k.status 
          FROM kehadiran2 k 
          JOIN users u ON k.user_id = u.id 
          WHERE k.id = $id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    // Jika data tidak ditemukan
    header('Location: absen_dasar.php');
    exit();
}

// Proses update absen
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $tanggal = $_POST['tanggal'];

    $update_query = "UPDATE kehadiran2 SET status = ?, tanggal = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "ssi", $status, $tanggal, $id);
    mysqli_stmt_execute($stmt);

    header('Location: absen_dasar.php?success=1');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-submit {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px;
            border-radius: 10px;
            display: block;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-submit:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">✍️ Edit Kehadiran</div>
        <form action="edit_absen.php?id=<?= $row['id'] ?>" method="POST">
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal:</label>
                <input type="date" id="tanggal" name="tanggal" class="form-control" value="<?= $row['tanggal'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Status Kehadiran:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" value="Hadir" <?= ($row['status'] == 'Hadir') ? 'checked' : '' ?>>
                    <label class="form-check-label">Hadir</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" value="Tidak Hadir" <?= ($row['status'] == 'Tidak Hadir') ? 'checked' : '' ?>>
                    <label class="form-check-label">Tidak Hadir</label>
                </div>
            </div>
            <button type="submit" class="btn-submit">Simpan</button>
        </form>
        <a href="absen_dasar.php" class="btn btn-secondary mt-3">Kembali ke Data Kehadiran</a>
    </div>
</body>

</html>