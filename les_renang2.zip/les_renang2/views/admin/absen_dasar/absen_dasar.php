<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

// Tentukan jumlah data per halaman
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Ambil urutan ASC/DESC dari query string atau default ASC
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';

// Query untuk mengambil data absen dasar dari tabel kehadiran2
$query = "SELECT k.id, nama, k.tanggal, k.status 
          FROM kehadiran2 k 
          JOIN users u ON k.user_id = u.id
          ORDER BY k.tanggal $sort_order
          LIMIT $start, $limit";
$result = mysqli_query($conn, $query);

// Menghitung total data
$count_query = "SELECT COUNT(*) AS total FROM kehadiran2";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_data / $limit);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kehadiran Latihan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table {
            border-radius: 10px;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-dashboard {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
            color: white;
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">
            📝 Data Kehadiran Dasar
        </div>

        <!-- Form untuk memilih urutan ASC/DESC -->
        <form method="get" action="">
            <select name="sort_order" onchange="this.form.submit()" class="form-select mb-3">
                <option value="ASC" <?= (isset($_GET['sort_order']) && $_GET['sort_order'] == 'ASC') ? 'selected' : '' ?>>Ascending</option>
                <option value="DESC" <?= (isset($_GET['sort_order']) && $_GET['sort_order'] == 'DESC') ? 'selected' : '' ?>>Descending</option>
            </select>
        </form>

        <!-- Tombol Absen -->
        <a href="absen.php" class="btn btn-success mb-3">Absen</a>

        <!-- Tombol untuk menyimpan PDF -->
        <button id="download-pdf" class="btn btn-primary mb-3">Download PDF</button>

        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = $start + 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$no}</td>";
                    echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                    echo "<td>" . date("d M Y", strtotime($row['tanggal'])) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "<td>";
                    echo "<a href='edit_absen.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a> ";
                    echo "<a href='hapus_absen.php?id={$row['id']}' class='btn btn-danger btn-sm'>Hapus</a>";
                    echo "</td>";
                    echo "</tr>";
                    $no++;
                }
                if (mysqli_num_rows($result) == 0) {
                    echo "<tr><td colspan='5' class='text-center text-muted'>Belum ada catatan latihan.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($page > 1) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page - 1 ?>&sort_order=<?= $sort_order ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&sort_order=<?= $sort_order ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page + 1 ?>&sort_order=<?= $sort_order ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <a href="../dashboard.php" class="btn-dashboard mt-3">🏠 Kembali ke Dashboard</a>
    </div>

    <!-- Script untuk generate PDF -->
    <script>
        document.getElementById('download-pdf').addEventListener('click', function() {
            const {
                jsPDF
            } = window.jspdf;
            const doc = new jsPDF();

            // Menambahkan judul
            doc.setFontSize(18);
            doc.text('Laporan Kehadiran', 14, 20);

            // Menambahkan kolom header
            doc.setFontSize(12);
            doc.text('No', 14, 30);
            doc.text('Nama Siswa', 30, 30);
            doc.text('Tanggal Kehadiran', 90, 30);
            doc.text('Status Kehadiran', 150, 30);

            // Menambahkan data dari tabel
            let y = 40;
            let no = 1;
            const rows = document.querySelectorAll('.table-striped tbody tr');
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                doc.text(no.toString(), 14, y);
                doc.text(cells[1].innerText, 30, y);
                doc.text(cells[2].innerText, 90, y);
                doc.text(cells[3].innerText, 150, y);
                y += 10;
                no++;
            });

            // Menyimpan PDF
            doc.save('laporan_kehadiran.pdf');
        });
    </script>

</body>

</html>