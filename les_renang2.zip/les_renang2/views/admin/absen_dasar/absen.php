<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

// Set jumlah data per halaman
$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Ambil daftar user dengan role "dasar" dengan pagination
$query = "SELECT id, nama FROM users WHERE role = 'dasar' LIMIT ? OFFSET ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $limit, $offset);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Hitung total data untuk pagination
$total_query = "SELECT COUNT(id) AS total FROM users WHERE role = 'dasar'";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_data = $total_row['total'];
$total_pages = ceil($total_data / $limit);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = htmlspecialchars($_POST['tanggal']);

    foreach ($_POST['status'] as $user_id => $status) {
        $status = htmlspecialchars($status);

        // Cek apakah sudah absen
        $check_query = "SELECT * FROM kehadiran2 WHERE user_id = ? AND tanggal = ?";
        $stmt = mysqli_prepare($conn, $check_query);
        mysqli_stmt_bind_param($stmt, "is", $user_id, $tanggal);
        mysqli_stmt_execute($stmt);
        $result_check = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result_check) == 0) {
            // Simpan absensi jika belum ada
            $insert_query = "INSERT INTO kehadiran2 (user_id, tanggal, waktu, status) VALUES (?, ?, NOW(), ?)";
            $stmt = mysqli_prepare($conn, $insert_query);
            mysqli_stmt_bind_param($stmt, "iss", $user_id, $tanggal, $status);
            mysqli_stmt_execute($stmt);
        }
    }

    header("Location: absen_dasar.php?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absen Kehadiran Dasar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-submit {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px;
            border-radius: 10px;
            display: block;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-submit:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 15px;
        }

        .pagination a {
            margin: 0 5px;
            padding: 8px 12px;
            text-decoration: none;
            background: #007bff;
            color: white;
            border-radius: 5px;
            transition: 0.3s;
        }

        .pagination a:hover {
            background: #0056b3;
        }

        .pagination .active {
            background: #0056b3;
            font-weight: bold;
        }

        .btn-dashboard {
            display: block;
            width: 100%;
            text-align: center;
            padding: 10px;
            background: #28a745;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 10px;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: #218838;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">📝 Absen Kehadiran - Kelas Dasar</div>
        <form action="absen.php" method="POST">
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal:</label>
                <input type="date" id="tanggal" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama User</th>
                        <th>Status Kehadiran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = $offset + 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $user_id = htmlspecialchars($row['id']);
                        $nama = htmlspecialchars($row['nama']);
                        echo "<tr>";
                        echo "<td>{$no}</td>";
                        echo "<td>{$nama}</td>";
                        echo "<td>
                            <div class='form-check form-check-inline'>
                                <input class='form-check-input' type='radio' name='status[$user_id]' value='Hadir' checked>
                                <label class='form-check-label'>Hadir</label>
                            </div>
                            <div class='form-check form-check-inline'>
                                <input class='form-check-input' type='radio' name='status[$user_id]' value='Tidak Hadir'>
                                <label class='form-check-label'>Tidak Hadir</label>
                            </div>
                        </td>";
                        echo "</tr>";
                        $no++;
                    }
                    ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="pagination">
                <?php if ($page > 1) : ?>
                    <a href="?page=<?= $page - 1 ?>">❮ Previous</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <a href="?page=<?= $i ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>

                <?php if ($page < $total_pages) : ?>
                    <a href="?page=<?= $page + 1 ?>">Next ❯</a>
                <?php endif; ?>
            </div>

            <br>
            <button type="submit" class="btn btn-submit">✅ Simpan Absen</button>
        </form>

        <a href="../absen_dasar/absen_dasar.php" class="btn-dashboard mt-3">🏠 Kembali ke Halaman Utama</a>
    </div>
</body>

</html>