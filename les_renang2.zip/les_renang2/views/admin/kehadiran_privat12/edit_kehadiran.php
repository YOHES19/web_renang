<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Mendapatkan ID dari URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Jika ID tidak ada, arahkan kembali ke laporan
if ($id == null) {
    header('Location: laporan_kehadiran.php');
    exit();
}

// Ambil data dari tabel absenprivat8
$query = "SELECT absenprivat12.id, users.username, absenprivat12.tanggal, absenprivat12.status 
          FROM absenprivat12 
          JOIN users ON absenprivat12.user_id = users.id";
$result = mysqli_query($conn, $query);

// Menangani jika data tidak ditemukan
if (mysqli_num_rows($result) == 0) {
    die("Data tidak ditemukan.");
}

// Ambil data kehadiran untuk ditampilkan di form
$row = mysqli_fetch_assoc($result);
$current_status = $row['status']; // Status kehadiran saat ini
$current_date = $row['tanggal']; // Tanggal kehadiran saat ini

// Proses update data ketika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_status = $_POST['status']; // Status yang baru
    $new_date = $_POST['tanggal']; // Tanggal yang baru

    // Update data kehadiran
    $update_query = "UPDATE absenprivat12 SET status = '$new_status', tanggal = '$new_date' WHERE id = '$id'";
    if (mysqli_query($conn, $update_query)) {
        header('Location: laporan_kehadiran.php'); // Redirect ke laporan setelah berhasil update
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kehadiran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(255, 16, 95), #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(255, 16, 95), #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(255, 16, 95), #00c3ff);
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 10px;
            transition: 0.3s;
            font-weight: bold;
        }

        .btn-custom:hover {
            background: linear-gradient(to right, rgb(255, 16, 95), #0099cc);
            color: white;
        }

        .form-select,
        .form-control {
            border-radius: 8px;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            border-radius: 10px;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Edit Kehadiran</div>
        <form method="POST">
            <div class="mb-3">
                <label for="status" class="form-label">Status Kehadiran</label>
                <select class="form-select" name="status" id="status" required>
                    <option value="Hadir" <?= $current_status == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                    <option value="Tidak Hadir" <?= $current_status == 'Tidak Hadir' ? 'selected' : '' ?>>Tidak Hadir</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $current_date ?>" required>
            </div>
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-custom">Update Kehadiran</button>
                <a href="laporan_kehadiran.php" class="btn btn-secondary mt-2">Kembali ke Laporan</a>
            </div>
        </form>
    </div>
</body>

</html>