<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: pantau_progres.php');
    exit();
}

$id = $_GET['id'];
$query = "SELECT * FROM progres WHERE id = $id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    header('Location: pantau_progres.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $_POST['tanggal'];
    $catatan = $_POST['catatan'];

    $updateQuery = "UPDATE progres SET tanggal='$tanggal', catatan='$catatan' WHERE id=$id";
    if (mysqli_query($conn, $updateQuery)) {
        header('Location: pantau_progres.php?success=update');
        exit();
    } else {
        echo "Gagal mengupdate data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Progres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h2>Edit Progres</h2>
        <form method="POST">
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $data['tanggal'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="catatan" class="form-label">Catatan</label>
                <textarea class="form-control" id="catatan" name="catatan" rows="4" required><?= htmlspecialchars($data['catatan']) ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="pantau_progres.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>

</html>