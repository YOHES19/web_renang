<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: pantau_progres.php');
    exit();
}

$id = $_GET['id'];
$deleteQuery = "DELETE FROM progres WHERE id = $id";

if (mysqli_query($conn, $deleteQuery)) {
    header('Location: pantau_progres.php?success=delete');
    exit();
} else {
    echo "Gagal menghapus data.";
}
