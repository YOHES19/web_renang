<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi database
include '../../../config/config.php';

// Proses penambahan data progres
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $catatan = $_POST['catatan'];

    // Query untuk menyimpan data progres
    $insert_sql = "INSERT INTO progres (user_id, tanggal, catatan) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("iss", $user_id, $tanggal, $catatan);
    if ($stmt->execute()) {
        header("Location: pantau_progres.php"); // Redirect setelah sukses
        exit();
    } else {
        $error = "Terjadi kesalahan saat menambahkan data progres.";
    }
}

// Query untuk mengambil data user
$sql_users = "SELECT id, username FROM users";
$result_users = $conn->query($sql_users);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Progres - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 30px;
        }

        .header {
            background: linear-gradient(135deg, #007bff, #6610f2);
            color: white;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 20px;
        }

        .btn-dashboard {
            background-color: #ffc107;
            color: #000;
            font-weight: bold;
        }

        .btn-dashboard:hover {
            background-color: #e0a800;
        }

        .btn-tambah {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">
            <h2>Tambah Progres Siswa</h2>
        </div>

        <!-- Tombol Kembali ke Pantau Progres -->
        <a href="pantau_progres.php" class="btn btn-dashboard mb-3 float-end">
            <i class=" "></i> Kembali ke Pantau Progres
        </a>

        <!-- Form tambah progres -->
        <form action="tambah_progres.php" method="POST">
            <div class="mb-3">
                <label for="user_id" class="form-label">Username Siswa</label>
                <select class="form-select" id="user_id" name="user_id" required>
                    <option value="">Pilih Username</option>
                    <?php
                    if ($result_users->num_rows > 0) {
                        // Loop untuk menampilkan setiap username dari database
                        while ($user = $result_users->fetch_assoc()) {
                            echo "<option value='" . $user['id'] . "'>" . $user['username'] . "</option>";
                        }
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" class="form-control" id="tanggal" name="tanggal" required>
            </div>

            <div class="mb-3">
                <label for="catatan" class="form-label">Catatan</label>
                <textarea class="form-control" id="catatan" name="catatan" rows="4" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Simpan Progres</button>
        </form>

        <?php
        if (isset($error)) {
            echo "<div class='alert alert-danger mt-3'>$error</div>";
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>