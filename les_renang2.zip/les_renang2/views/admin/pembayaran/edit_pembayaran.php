<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi ke database
include '../../../config/config.php';

// Menangani jika id pembayaran tidak ada
if (!isset($_GET['id'])) {
    header('Location: laporan_pembayaran.php');
    exit();
}

// Ambil data pembayaran berdasarkan id
$id = $_GET['id'];
$query = "SELECT * FROM pembayaran WHERE id = $id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

// Menangani aksi Update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jumlah = $_POST['jumlah'];
    $status = $_POST['status'];
    $tanggal = $_POST['tanggal'];

    // Query untuk update data pembayaran
    $update_query = "UPDATE pembayaran SET jumlah = ?, status = ?, tanggal = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "ssss", $jumlah, $status, $tanggal, $id);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Pembayaran berhasil diperbarui!'); window.location.href='laporan_pembayaran.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui pembayaran!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f7c2f7, rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .card {
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #6c5ce7;
            color: #fff;
            text-align: center;
            font-size: 24px;
            border-radius: 12px 12px 0 0;
            padding: 20px;
        }

        .form-control,
        .form-select {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #ddd;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #6c5ce7;
            box-shadow: 0 0 10px rgba(108, 92, 231, 0.5);
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-size: 16px;
        }

        .btn-primary {
            background-color: #6c5ce7;
            border: none;
        }

        .btn-primary:hover {
            background-color: #5a4ec7;
        }

        .btn-secondary {
            background-color: #aaa;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #888;
        }

        .d-flex {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Edit Pembayaran</h1>
            </div>
            <div class="card-body">
                <!-- Form untuk edit pembayaran -->
                <form method="POST" action="edit_pembayaran.php?id=<?= $row['id'] ?>">
                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Jumlah Pembayaran</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?= $row['jumlah'] ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status Pembayaran</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="Lunas" <?= ($row['status'] == 'Lunas') ? 'selected' : '' ?>>Lunas</option>
                            <option value="Belum Lunas" <?= ($row['status'] == 'Belum Lunas') ? 'selected' : '' ?>>Belum Lunas</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Pembayaran</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $row['tanggal'] ?>" required>
                    </div>

                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">Update Pembayaran</button>
                        <a href="laporan_pembayaran.php" class="btn btn-secondary">Kembali ke Laporan Pembayaran</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Optional Bootstrap JS and Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>

</html>