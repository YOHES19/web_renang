<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi ke database
include '../../../config/config.php';

// Memastikan bahwa form telah disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id']; // Mengambil user_id dari input form
    $jumlah = $_POST['jumlah']; // Mengambil jumlah pembayaran dari input form
    $status = $_POST['status']; // Mengambil status pembayaran dari input form
    $tanggal = $_POST['tanggal']; // Mengambil tanggal pembayaran dari input form

    // Query untuk menambah pembayaran ke dalam database
    $query = "INSERT INTO pembayaran (user_id, jumlah, status, tanggal) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssss", $user_id, $jumlah, $status, $tanggal);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Pembayaran berhasil ditambahkan!'); window.location.href='laporan_pembayaran.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan pembayaran!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pembayaran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f7c2f7, rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }

        .card {
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #6c5ce7;
            color: #fff;
            text-align: center;
            font-size: 24px;
            border-radius: 12px 12px 0 0;
            padding: 20px;
        }

        .form-control,
        .form-select {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #ddd;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #6c5ce7;
            box-shadow: 0 0 10px rgba(108, 92, 231, 0.5);
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-size: 16px;
        }

        .btn-primary {
            background-color: #6c5ce7;
            border: none;
        }

        .btn-primary:hover {
            background-color: #5a4ec7;
        }

        .btn-secondary {
            background-color: #aaa;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #888;
        }

        .btn-danger {
            background-color: #e74c3c;
            border: none;
        }

        .btn-danger:hover {
            background-color: #c0392b;
        }

        .d-flex {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Tambah Pembayaran</h1>
            </div>
            <div class="card-body">
                <!-- Form untuk tambah pembayaran -->
                <form method="POST" action="tambah_pembayaran.php">
                    <div class="mb-3">
                        <label for="user_id" class="form-label">Nama Siswa</label>
                        <select class="form-select" id="user_id" name="user_id" required>
                            <option value="">Pilih Siswa</option>
                            <?php
                            // Mengambil data pengguna dengan role "user" untuk pilihan
                            $user_query = "SELECT * FROM users WHERE role = 'user'";
                            $user_result = mysqli_query($conn, $user_query);
                            while ($user = mysqli_fetch_assoc($user_result)) {
                                echo "<option value='{$user['id']}'>{$user['username']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Jumlah Pembayaran</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah" required>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status Pembayaran</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="Lunas">Lunas</option>
                            <option value="Belum Lunas">Belum Lunas</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Pembayaran</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>

                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">Tambah Pembayaran</button>
                        <a href="laporan_pembayaran.php" class="btn btn-secondary">Kembali ke Laporan Pembayaran</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Optional Bootstrap JS and Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>

</html>