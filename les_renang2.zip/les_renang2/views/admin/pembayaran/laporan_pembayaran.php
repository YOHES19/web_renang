<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi ke database
include '../../../config/config.php';

// Query untuk mengambil data pembayaran
$query = "SELECT pembayaran.id, users.username, pembayaran.jumlah, pembayaran.status, pembayaran.tanggal 
        FROM pembayaran 
        JOIN users ON pembayaran.user_id = users.id"; // Menyertakan nama user berdasarkan user_id
$result = mysqli_query($conn, $query);

// Menangani aksi Hapus
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM pembayaran WHERE id = $delete_id";
    if (mysqli_query($conn, $delete_query)) {
        echo "<script>alert('Pembayaran berhasil dihapus!'); window.location.href='laporan_pembayaran.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus pembayaran!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pembayaran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #f7c2f7, rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 1000px;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        .badge-success {
            background-color: #28a745;
        }

        .card {
            margin-top: 20px;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2 class="mb-4 text-center">Laporan Pembayaran</h2>

        <!-- Card untuk Tabel -->
        <div class="card shadow-sm">
            <div class="card-body">
                <!-- Tombol untuk menambah pembayaran dan kembali ke dashboard sejajar di dalam card -->
                <div class="d-flex justify-content-between mb-3">
                    <div class="d-inline-flex">
                        <a href="tambah_pembayaran.php" class="btn btn-primary me-2">Tambah Pembayaran</a>
                        <!-- Tombol Save as PDF -->
                        <button id="download-pdf" class="btn btn-primary">Save as PDF</button>
                    </div>
                    <a href="../dashboard.php" class="btn btn-secondary">Kembali ke Dashboard</a>
                </div>
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Siswa</th>
                            <th>Jumlah Pembayaran</th>
                            <th>Status Pembayaran</th>
                            <th>Tanggal Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $row['username'] ?></td>
                                <td>Rp <?= number_format($row['jumlah'], 2, ',', '.') ?></td>
                                <td><?= ucfirst($row['status']) ?></td>
                                <td><?= $row['tanggal'] ?></td>
                                <td>
                                    <!-- Tombol Edit -->
                                    <a href="edit_pembayaran.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>

                                    <!-- Tombol Hapus -->
                                    <a href="?delete_id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pembayaran ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Optional Bootstrap JS and Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <!-- Script untuk generate PDF -->
    <script>
        document.getElementById('download-pdf').addEventListener('click', function() {
            const {
                jsPDF
            } = window.jspdf;
            const doc = new jsPDF();

            // Menambahkan judul
            doc.setFontSize(18);
            doc.text('Laporan Pembayaran', 14, 20);

            // Menambahkan kolom header
            doc.setFontSize(12);
            doc.text('No', 14, 30);
            doc.text('Nama Siswa', 30, 30);
            doc.text('Jumlah Pembayaran', 90, 30);
            doc.text('Status Pembayaran', 150, 30);
            doc.text('Tanggal Pembayaran', 210, 30);

            // Menambahkan data dari tabel
            let y = 40;
            let no = 1;
            const rows = document.querySelectorAll('.table-striped tbody tr');
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                doc.text(no.toString(), 14, y);
                doc.text(cells[1].innerText, 30, y);
                doc.text(cells[2].innerText, 90, y);
                doc.text(cells[3].innerText, 150, y);
                doc.text(cells[4].innerText, 210, y);
                y += 10;
                no++;
            });

            // Menyimpan PDF
            doc.save('laporan_pembayaran.pdf');
        });
    </script>
</body>

</html>