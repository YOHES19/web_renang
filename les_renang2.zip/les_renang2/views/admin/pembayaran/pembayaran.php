<?php
include '../../../config/config.php';
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <title>Kelola Pembayaran</title>
    <link href="../../assets/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-4">
        <h2>Daftar Pembayaran</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>User ID</th>
                    <th>Jumlah</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM pembayaran";
                $result = mysqli_query($conn, $query);
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$no}</td>
                        <td>{$row['user_id']}</td>
                        <td>Rp " . number_format($row['jumlah'], 2, ',', '.') . "</td>
                        <td>" . ucfirst($row['status']) . "</td>
                        <td>{$row['tanggal']}</td>
                        <td>";
                    if ($row['status'] == 'pending') {
                        echo "<a href='../../controllers/pembayaran.php?konfirmasi_id={$row['id']}' class='btn btn-success'>Konfirmasi</a>";
                    } else {
                        echo "<span class='badge bg-success'>Lunas</span>";
                    }
                    echo "</td></tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>