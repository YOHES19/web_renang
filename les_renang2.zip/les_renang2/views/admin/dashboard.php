<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../../config/config.php';

// Ambil data user dari database
$user_id = $_SESSION['user_id'];
$query = "SELECT username FROM users WHERE id = '$user_id' AND role = 'admin'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
$username = $user ? htmlspecialchars($user['username']) : 'Admin';

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Les Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(255, 255, 255);
        }

        .sidebar {
            height: 100vh;
            width: 260px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
            transition: all 0.3s;
            box-shadow: 4px 0px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            overflow-y: auto;
            /* Biar bisa scroll naik turun */
            scrollbar-width: thin;
            /* Untuk Firefox */
            scrollbar-color: #007bff #343a40;
            /* Warna scrollbar */
        }

        /* Untuk browser berbasis WebKit (Chrome, Edge, Safari) */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: #343a40;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 4px;
        }

        .sidebar .sidebar-header {
            font-size: 24px;
            color: white;
            margin-bottom: 40px;
            padding-left: 20px;
            text-align: left;
        }

        .sidebar a {
            color: white;
            padding: 15px 20px;
            text-decoration: none;
            display: flex;
            align-items: center;
            font-size: 18px;
            border-radius: 5px;
            transition: 0.3s;
            margin-bottom: 10px;
        }

        .sidebar a:hover {
            background-color: #007bff;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.4);
        }

        .sidebar a i {
            margin-right: 10px;
            font-size: 20px;
        }

        .content {
            margin-left: 260px;
            padding: 20px;
        }

        .header {
            background: linear-gradient(135deg, rgb(118, 182, 250), rgb(160, 106, 247));
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
        }

        .card {
            border-radius: 10px;
            transition: 0.3s;
            overflow: hidden;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
        }

        .carousel-item img {
            width: 100%;
            height: 500px;
            object-fit: cover;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <div class="sidebar text-center">
        <div class="sidebar-header">
            <h3>Dashboard Admin</h3>
        </div>
        <a href="../admin/kelola_pelatih/kelola_pelatih.php"><i class="fas fa-chalkboard-teacher"></i> Kelola Pelatih</a>
        <a href="../admin/kelola_user/kelola_user.php"><i class="fas fa-users"></i> Kelola User</a>
        <a href="../admin/kehadiran/laporan_kehadiran.php"><i class="fas fa-clipboard-list"></i>Kehadiran</a>
        <a href="../admin/pembayaran/laporan_pembayaran.php"><i class="fas fa-file-invoice-dollar"></i> Laporan Pembayaran</a>
        <a href="../admin/waktu_pretes/waktu_pretes1.php"><i class="fas fa-clock"></i> Waktu Pretes</a>
        <a href="../admin/pantau_progres/pantau_progres.php"><i class="fas fa-chart-line"></i> Pantau Progres</a>
        <a href="../admin/absen_dasar/absen_dasar.php"><i class="fas fa-clipboard-check"></i> Absen Dasar</a>
        <a href="../admin/progres_dasar/progres_dasar.php"><i class="fas fa-tasks"></i> Progres Dasar</a>
        <a href="../admin/pembayaran_dasar/pembayaran_dasar.php"><i class="fas fa-credit-card"></i> Pembayaran Dasar</a>
        <a href="../../logout.php" class="btn btn-danger mt-3"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content" id="content">
        <div class="header">
            <h1>👨🏻‍💻 Selamat Datang Admin <?= $username ?> 👨🏻‍💻</h1>
        </div>

        <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="1.jpeg" class="d-block w-100" alt="Slide 1">
                </div>
                <div class="carousel-item">
                    <img src="2.jpeg" class="d-block w-100" alt="Slide 2">
                </div>
                <div class="carousel-item">
                    <img src="3.jpeg" class="d-block w-100" alt="Slide 3">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>

        <div class="row mt-4">
            <!-- Kehadiran Privat 8 -->
            <div class="col-md-4">
                <div class="card text-center p-4 bg-info text-white">
                    <h5><i class="fas fa-user-check"></i> Kehadiran Privat 8</h5>
                    <a href="../admin/kehadiran_privat8/laporan_kehadiran.php" class="btn btn-light mt-2">Lihat</a>
                </div>
            </div>

            <!-- Pembayaran Privat 8 -->
            <div class="col-md-4">
                <div class="card text-center p-4 bg-info text-white">
                    <h5><i class="fas fa-money-bill-wave"></i> Pembayaran Privat 8</h5>
                    <a href="../admin/pembayaran_privat8/pembayaran_dasar.php" class="btn btn-light mt-2">Lihat</a>
                </div>
            </div>

            <!-- Kehadiran Privat 12 -->
            <div class="col-md-4">
                <div class="card text-center p-4 bg-success text-white">
                    <h5><i class="fas fa-user-check"></i> Kehadiran Privat 12</h5>
                    <a href="../admin/kehadiran_privat12/laporan_kehadiran.php" class="btn btn-light mt-2">Lihat</a>
                </div>
            </div>

            <!-- Pembayaran Privat 12 -->
            <div class="col-md-4 mt-4">
                <div class="card text-center p-4 bg-success text-white">
                    <h5><i class="fas fa-money-bill-wave"></i> Pembayaran Privat 12</h5>
                    <a href="../admin/pembayaran_privat12/pembayaran_dasar.php" class="btn btn-light mt-2">Lihat</a>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>