<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

// Ambil ID progres yang akan dihapus
$id = $_GET['id'];

// Query untuk menghapus data progres
$query = "DELETE FROM progres2 WHERE id = '$id'";
if (mysqli_query($conn, $query)) {
    header('Location: progres_dasar.php');
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}
