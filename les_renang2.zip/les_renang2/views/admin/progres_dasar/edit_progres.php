<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

// Ambil ID progres yang akan diedit
$id = $_GET['id'];

// Query untuk mendapatkan data progres yang akan diedit
$query = "SELECT * FROM progres2 WHERE id = '$id'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

// Proses untuk mengupdate data progres
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $catatan = $_POST['catatan'];

    // Query untuk mengupdate data progres
    $update_query = "UPDATE progres2 SET user_id = '$user_id', tanggal = '$tanggal', catatan = '$catatan' WHERE id = '$id'";
    if (mysqli_query($conn, $update_query)) {
        header('Location: progres_dasar.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Ambil data pengguna dengan role dasar untuk dropdown
$user_query = "SELECT * FROM users WHERE role = 'dasar'";
$user_result = mysqli_query($conn, $user_query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Progres Dasar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table {
            border-radius: 10px;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-dashboard {
            background: linear-gradient(to right, #007bff, rgb(0, 255, 221));
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, #0056b3, rgb(0, 204, 136));
            color: white;
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <h2>Edit Progres Dasar</h2>
        </div>
        <form method="POST">
            <div class="mb-3">
                <label for="user_id" class="form-label">Nama Siswa</label>
                <select class="form-select" name="user_id" required>
                    <option value="">Pilih Siswa</option>
                    <?php while ($user = mysqli_fetch_assoc($user_result)) : ?>
                        <option value="<?= $user['id'] ?>" <?= ($user['id'] == $data['user_id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($user['nama']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" class="form-control" name="tanggal" value="<?= $data['tanggal'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="catatan" class="form-label">Catatan</label>
                <textarea class="form-control" name="catatan" rows="3" required><?= $data['catatan'] ?></textarea>
            </div>
            <button type="submit" class="btn btn-dashboard">Update</button>
            <a href="progres_dasar.php" class="btn btn-dashboard mt-3">Kembali</a>
        </form>
    </div>
</body>

</html>