<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

// Tentukan jumlah data per halaman
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Ambil urutan ASC/DESC dari query string atau default ASC
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';

// Query untuk mengambil data progres dari tabel progres2
$query = "SELECT p.id, u.nama, p.tanggal, p.catatan
          FROM progres2 p
          JOIN users u ON p.user_id = u.id
          ORDER BY p.tanggal $sort_order
          LIMIT $start, $limit";
$result = mysqli_query($conn, $query);

// Menghitung total data
$count_query = "SELECT COUNT(*) AS total FROM progres2";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_data / $limit);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progres Dasar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table {
            border-radius: 10px;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-dashboard {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
            color: white;
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">
            📝 Progres Dasar
        </div>

        <!-- Tombol Tambah Progres -->
        <a href="tambah_progres.php" class="btn btn-success mb-3">Tambah Progres</a>

        <table class="table table-hover table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Tanggal</th>
                    <th>Catatan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = $start + 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$no}</td>";
                    echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                    echo "<td>" . date("d M Y", strtotime($row['tanggal'])) . "</td>";
                    echo "<td>" . htmlspecialchars($row['catatan']) . "</td>";
                    echo "<td>";
                    echo "<a href='edit_progres.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a> ";
                    echo "<a href='hapus_progres.php?id={$row['id']}' class='btn btn-danger btn-sm'>Hapus</a>";
                    echo "</td>";
                    echo "</tr>";
                    $no++;
                }
                if (mysqli_num_rows($result) == 0) {
                    echo "<tr><td colspan='5' class='text-center text-muted'>Belum ada data progres dasar.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($page > 1) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page - 1 ?>&sort_order=<?= $sort_order ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&sort_order=<?= $sort_order ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page + 1 ?>&sort_order=<?= $sort_order ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <a href="../dashboard.php" class="btn-dashboard mt-3">🏠 Kembali ke Dashboard</a>
    </div>

</body>

</html>