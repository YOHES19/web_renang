<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php'; // Pastikan koneksi database tersedia

// Pastikan ada parameter ID pengguna
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: kelola_user.php?error=ID tidak valid');
    exit();
}

$id = intval($_GET['id']);

// Cek apakah pengguna dengan ID ini ada di database
$query = "SELECT * FROM users WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 0) {
    header('Location: kelola_user.php?error=Pengguna tidak ditemukan');
    exit();
}

// Hapus pengguna dari database
$query = "DELETE FROM users WHERE id = $id";
if (mysqli_query($conn, $query)) {
    header('Location: kelola_user.php?success=Pengguna berhasil dihapus');
    exit();
} else {
    header('Location: kelola_user.php?error=Gagal menghapus pengguna');
    exit();
}
