<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../../../config/config.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "ID tidak ditemukan.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $_POST['tanggal'];
    $jumlah = $_POST['jumlah'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE privat8 SET tanggal=?, jumlah=?, status=? WHERE id=?");
    $stmt->bind_param("sssi", $tanggal, $jumlah, $status, $id);

    if ($stmt->execute()) {
        header("Location: pembayaran_dasar.php?pesan=update_sukses");
        exit();
    } else {
        echo "Gagal memperbarui data.";
    }
}

$query = $conn->query("SELECT * FROM privat8 WHERE id = $id");
$data = $query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, rgb(138, 1, 165), #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(138, 1, 165), #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-simpan {
            background: linear-gradient(to right, rgb(138, 1, 165), #00c3ff);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-simpan:hover {
            background: linear-gradient(to right, rgb(138, 1, 165), #0099cc);
        }

        .btn-batal {
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-batal:hover {
            background: #c82333;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Edit Data Pembayaran</div>
        <form method="post">
            <div class="mb-3">
                <label class="form-label">Tanggal</label>
                <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Jumlah</label>
                <input type="number" name="jumlah" value="<?= $data['jumlah'] ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-control" required>
                    <option value="Sudah Bayar" <?= ($data['status'] == 'Sudah Bqyar') ? 'selected' : '' ?>>Sudah Bayar</option>
                    <option value="Belum Bayar " <?= ($data['status'] == 'Belum Bayar') ? 'selected' : '' ?>>Belum Bayar</option>
                </select>
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-simpan">Simpan</button>
                <a href="pembayaran_dasar.php" class="btn btn-batal">Batal</a>
            </div>
        </form>
    </div>
</body>

</html>