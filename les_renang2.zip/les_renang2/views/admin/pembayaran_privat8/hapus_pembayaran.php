<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../../../config/config.php';

$id = $_GET['id'] ?? null;

if ($id) {
    $query = $conn->query("DELETE FROM privat8 WHERE id = $id");

    if ($query) {
        header("Location: pembayaran_dasar.php?pesan=hapus_sukses");
    } else {
        echo "Gagal menghapus data.";
    }
} else {
    echo "ID tidak ditemukan.";
}
