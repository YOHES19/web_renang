<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'user') {
    header('Location: ../login.php');
    exit();
}

include '../../config/config.php';

$user_id = $_SESSION['user_id'];
$query = "SELECT username FROM users WHERE id = '$user_id' AND role = 'user'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
$username = $user ? htmlspecialchars($user['username']) : 'User';

// Pagination
$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$query = "SELECT * FROM waktu_pretes2 WHERE user_id = '$user_id' ORDER BY tanggal DESC LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);

$total_query = "SELECT COUNT(*) AS total FROM waktu_pretes2 WHERE user_id = '$user_id'";
$total_result = mysqli_query($conn, $total_query);
$total_data = mysqli_fetch_assoc($total_result)['total'];
$total_pages = ceil($total_data / $limit);

$data = mysqli_num_rows($result) > 0 ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pretes 100m</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, rgb(7, 206, 106), #00ccff);
            color: white;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            margin: auto;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(7, 206, 106), #00c3ff);
            color: white;
            margin-bottom: 20px;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }

        .btn-dashboard {
            background: linear-gradient(to right, rgb(7, 206, 106), #00c3ff);
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-weight: bold;
            text-decoration: none;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, rgb(7, 206, 106), #0099cc);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            🏊 Hasil Pretes 100m - <?= $username ?> 🏊
        </div>

        <p class="text-center text-muted">Berikut adalah hasil pretes 100 meter Anda berdasarkan gaya renang.</p>

        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Waktu</th>
                    <th>Dada 100m</th>
                    <th>Bebas 100m</th>
                    <th>Kupu-Kupu 100m</th>
                    <th>Punggung 100m</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($data) > 0): ?>
                    <?php foreach ($data as $index => $row): ?>
                        <tr>
                            <td><?= $index + 1 + $offset ?></td>
                            <td><?= date("d M Y", strtotime($row['tanggal'])) ?></td>
                            <td><?= htmlspecialchars($row['waktu']) ?></td>
                            <td><?= htmlspecialchars($row['waktu_gaya_dada_100m']) ?></td>
                            <td><?= htmlspecialchars($row['waktu_gaya_bebas_100m']) ?></td>
                            <td><?= htmlspecialchars($row['waktu_gaya_kupu_kupu_100m']) ?></td>
                            <td><?= htmlspecialchars($row['waktu_gaya_punggung_100m']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Belum ada data pretes 100m untuk ditampilkan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                    </li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <a href="dashboard.php" class="btn-dashboard mt-3">🏠 Kembali ke Dashboard</a>
    </div>
</body>

</html>