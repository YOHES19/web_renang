<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'user') {
    header('Location: ../login.php');
    exit();
}

include '../../config/config.php';

// Ambil data user dari database
$user_id = $_SESSION['user_id'];
$query = "SELECT nama FROM users WHERE id = '$user_id' AND role = 'user'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
$nama = $user ? htmlspecialchars($user['nama']) : 'User';
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            display: flex;
            background-color: #f8f9fa;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, rgb(5, 248, 127), rgb(64, 155, 245));
            color: white;
            padding: 20px;
            position: fixed;
            transition: transform 0.3s ease-in-out;
        }

        .sidebar.hidden {
            transform: translateX(-100%);
        }

        .sidebar a {
            color: #ffffff;
            text-decoration: none;
            display: block;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 10px;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: rgb(248, 5, 86);
        }

        .content {
            margin-left: 300px;
            padding: 30px;
            width: 100%;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.full-width {
            margin-left: 0;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 213px;
            background: rgb(51, 134, 223);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.hidden+.toggle-btn {
            left: 20px;
        }

        .header {
            background: linear-gradient(135deg, rgb(7, 206, 106), rgb(65, 229, 235));
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
        }

        .carousel img {
            height: 450px;
            object-fit: cover;
            border-radius: 10px;
        }

        .carousel-container {
            margin-top: 30px;
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h4 class="text-center">User Menu</h4>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="progres_user.php">📈 Lihat Catatan Latihan</a>
        <a href="kehadiran_user.php">📝 Lihat Kehadiran</a>
        <a href="hasil_pretes_user.php">📋 Hasil Pretes 50m</a>
        <a href="hasil_pretes_user2.php">🏊‍♂️ Hasil Pretes 100m</a>
        <a href="pembayaran_user.php">💳 Lihat Status Pembayaran</a>
        <a href="../../logout.php">🚪 Logout</a>
    </div>
    <button class="toggle-btn" id="toggleBtn" onclick="toggleSidebar()">☰</button>
    <div class="content" id="content">
        <div class="header">
            <h1>Selamat Datang Atlet <?= $nama ?> 🏊</h1>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">📊 Catatan Latihan</h5>
                        <p class="card-text">Lihat Catatan latihanmu.</p>
                        <a href="progres_user.php" class="btn btn-primary">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">📅 Kehadiran</h5>
                        <p class="card-text">Cek daftar kehadiranmu.</p>
                        <a href="kehadiran_user.php" class="btn btn-primary">Lihat</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title">💰 Pembayaran</h5>
                        <p class="card-text">Cek status pembayaran.</p>
                        <a href="pembayaran_user.php" class="btn btn-primary">Lihat</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- CAROUSEL FOTO LATIHAN -->
        <div class="carousel-container">
            <h3 class="text-center">📸 Galeri Latihan</h3>
            <div id="trainingCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="../admin/1.jpeg" class="d-block w-100" alt="Latihan 1">
                    </div>
                    <div class="carousel-item">
                        <img src="../admin/2.jpeg" class="d-block w-100" alt="Latihan 2">
                    </div>
                    <div class="carousel-item">
                        <img src="../admin/3.jpeg" class="d-block w-100" alt="Latihan 3">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#trainingCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#trainingCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                </button>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const content = document.getElementById("content");
            const toggleBtn = document.getElementById("toggleBtn");

            sidebar.classList.toggle("hidden");
            content.classList.toggle("full-width");

            // Jika sidebar tersembunyi, pindahkan tombol ke kiri
            if (sidebar.classList.contains("hidden")) {
                toggleBtn.style.left = "10px"; // Tombol di kiri
            } else {
                toggleBtn.style.left = "213px"; // Tombol kembali ke posisi semula
            }
        }
    </script>
</body>

</html>