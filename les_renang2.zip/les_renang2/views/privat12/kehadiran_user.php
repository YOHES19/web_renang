<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'privat12') {
    header('Location: ../login.php');
    exit();
}

include '../../config/config.php';

// Ambil user_id dari session
$user_id = $_SESSION['user_id'];

// Pagination setup
$limit = 12; // Jumlah data per halaman
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Query untuk menghitung jumlah total data
$query_count = "SELECT COUNT(*) AS total FROM absenprivat12 WHERE user_id = '$user_id'";
$result_count = mysqli_query($conn, $query_count);
$row_count = mysqli_fetch_assoc($result_count);
$total_records = $row_count['total'];
$total_pages = ceil($total_records / $limit);

// Query untuk mengambil data kehadiran dengan limit
$query = "SELECT * FROM absenprivat12 WHERE user_id = '$user_id' ORDER BY tanggal DESC LIMIT $start, $limit";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kehadiran Latihan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(29, 1, 41), #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(29, 1, 41), #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table {
            border-radius: 10px;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-dashboard {
            background: linear-gradient(to right, rgb(29, 1, 41), #00c3ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, rgb(29, 1, 41), #0099cc);
            color: white;
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">
            📝 Data Kehadiran
        </div>

        <p class="text-center text-muted">Riwayat kehadiran latihan yang telah Anda Laksanakan.</p>

        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = $start + 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$no}</td>";
                    echo "<td>" . date("d M Y", strtotime($row['tanggal'])) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "</tr>";
                    $no++;
                }
                if (mysqli_num_rows($result) == 0) {
                    echo "<tr><td colspan='3' class='text-center text-muted'>Belum ada catatan latihan.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($page > 1) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <a href="dashboard.php" class="btn-dashboard mt-3">🏠 Kembali ke Dashboard</a>
    </div>

</body>

</html>