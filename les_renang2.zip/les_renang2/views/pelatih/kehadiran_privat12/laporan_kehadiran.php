<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Ambil data dari tabel absenprivat12
$query = "SELECT absenprivat12.id, users.username, absenprivat12.tanggal, absenprivat12.status 
          FROM absenprivat12 
          JOIN users ON absenprivat12.user_id = users.id";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query gagal: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kehadiran Privat 12</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(255, 16, 95), #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 1000px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(255, 16, 95), #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table thead {
            background: linear-gradient(to right, rgb(255, 16, 95), #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgb(212, 194, 255);
            transition: 0.3s;
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(255, 16, 95), #00c3ff);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 10px;
            margin-right: 10px;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background: linear-gradient(to right, rgb(255, 16, 95), #0099cc);
            color: white;
        }

        .table td,
        .table th {
            text-align: center;
            vertical-align: middle;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Laporan Kehadiran Privat 12</div>

        <div class="mb-3 d-flex justify-content-between">
            <div>
                <a href="tambah_kehadiran.php" class="btn-custom">Tambah Kehadiran</a>
                <button id="download-pdf" class="btn-custom">Simpan sebagai PDF</button>
            </div>
            <a href="../dashboard.php" class="btn-custom">Kembali ke Dashboard</a>
        </div>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Tanggal Kehadiran</th>
                    <th>Status Kehadiran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1;
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['tanggal']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td>
                            <a href="edit_kehadiran.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="hapus_kehadiran.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        document.getElementById('download-pdf').addEventListener('click', function() {
            const {
                jsPDF
            } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(18);
            doc.text('Laporan Kehadiran Privat 12', 14, 20);

            doc.setFontSize(12);
            doc.text('No', 14, 30);
            doc.text('Nama Siswa', 30, 30);
            doc.text('Tanggal Kehadiran', 90, 30);
            doc.text('Status Kehadiran', 150, 30);

            let y = 40;
            let no = 1;
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                doc.text(no.toString(), 14, y);
                doc.text(cells[1].innerText, 30, y);
                doc.text(cells[2].innerText, 90, y);
                doc.text(cells[3].innerText, 150, y);
                y += 10;
                no++;
            });

            doc.save('laporan_kehadiran_privat12.pdf');
        });
    </script>
</body>

</html>