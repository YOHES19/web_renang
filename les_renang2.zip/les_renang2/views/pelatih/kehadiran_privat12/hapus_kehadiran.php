<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Mendapatkan ID dari URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Jika ID tidak ada, arahkan kembali ke laporan
if ($id == null) {
    header('Location: laporan_kehadiran.php');
    exit();
}

// Query untuk menghapus data kehadiran berdasarkan ID
$query = "DELETE FROM absenprivat12 WHERE id = '$id'";

// Menjalankan query
if (mysqli_query($conn, $query)) {
    // Redirect kembali ke laporan kehadiran setelah berhasil menghapus
    header('Location: laporan_kehadiran.php');
    exit();
} else {
    // Jika gagal menghapus, tampilkan error
    echo "Error deleting record: " . mysqli_error($conn);
}
