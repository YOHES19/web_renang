<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Fungsi untuk mengambil data pretes berdasarkan ID
function getWaktuPretesById($conn, $id)
{
    $sql = "SELECT wp.*, u.nama as user_nama 
            FROM waktu_pretes wp
            JOIN users u ON wp.user_id = u.id
            WHERE wp.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Fungsi untuk mendapatkan daftar pengguna untuk dropdown
function getUsers($conn)
{
    $sql = "SELECT id, nama FROM users";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

if (isset($_GET['id'])) {
    $pretesId = $_GET['id'];
    $pretesData = getWaktuPretesById($conn, $pretesId);
    if (!$pretesData) {
        die("Data pretes tidak ditemukan.");
    }
}

$users = getUsers($conn);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pretes - Les Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(to right, #f7c2f7, rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .card-header {
            background-color: #007bff;
            color: white;
        }

        .card-body {
            background-color: rgb(248, 250, 250);
        }

        .form-label {
            font-weight: bold;
        }

        .btn-success i {
            margin-right: 8px;
        }

        .btn-danger i {
            margin-right: 8px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <a href="../waktu_pretes/waktu_pretes1.php" class="btn btn-secondary mb-4">Kembali ke Waktu Pretes</a>

        <!-- Form Edit Pretes -->
        <div class="card">
            <div class="card-header text-center">
                <h4>Edit Data Pretes</h4>
            </div>
            <div class="card-body">
                <form action="proses_edit_pretes.php" method="POST">
                    <input type="hidden" name="id" value="<?= $pretesData['id'] ?>">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="user_id" class="form-label">Nama Peserta</label>
                            <select class="form-select" name="user_id" required>
                                <option value="">Pilih Nama</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>" <?= ($user['id'] == $pretesData['user_id']) ? 'selected' : '' ?>><?= $user['nama'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="tanggal" class="form-label">Tanggal</label>
                            <input type="date" class="form-control" name="tanggal" value="<?= $pretesData['tanggal'] ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="waktu" class="form-label">Waktu</label>
                            <input type="time" class="form-control" name="waktu" value="<?= $pretesData['waktu'] ?>" required>
                        </div>
                    </div>

                    <div class="row g-3 mt-2">
                        <div class="col-md-3">
                            <label for="waktu_gaya_dada" class="form-label">Gaya Dada</label>
                            <input type="text" class="form-control" name="waktu_gaya_dada" value="<?= $pretesData['waktu_gaya_dada'] ?>" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label for="waktu_gaya_bebas" class="form-label">Gaya Bebas</label>
                            <input type="text" class="form-control" name="waktu_gaya_bebas" value="<?= $pretesData['waktu_gaya_bebas'] ?>" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label for="waktu_gaya_kupu_kupu" class="form-label">Gaya Kupu-Kupu</label>
                            <input type="text" class="form-control" name="waktu_gaya_kupu_kupu" value="<?= $pretesData['waktu_gaya_kupu_kupu'] ?>" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label for="waktu_gaya_punggung" class="form-label">Gaya Punggung</label>
                            <input type="text" class="form-control" name="waktu_gaya_punggung" value="<?= $pretesData['waktu_gaya_punggung'] ?>" placeholder="00:00:00" required>
                        </div>
                    </div>

                    <!-- Menempatkan tombol di tengah -->
                    <div class="d-flex justify-content-center mt-4">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-pencil-square"></i> Update Pretes
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <!-- End Form Edit Pretes -->

    </div>
</body>

</html>