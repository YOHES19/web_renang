<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $catatan = $_POST['catatan'];

    $query = "INSERT INTO progres2 (user_id, tanggal, catatan) VALUES ('$user_id', '$tanggal', '$catatan')";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Progres berhasil ditambahkan!'); window.location.href='progres_dasar.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan progres.');</script>";
    }
}

// Query untuk mengambil nama siswa dengan role dasar
$query_user = "SELECT id, nama FROM users WHERE role = 'dasar'";
$result_user = mysqli_query($conn, $query_user);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Progres Dasar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .form-label {
            font-weight: bold;
        }

        .btn-dashboard {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
            color: white;
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="header">
            <h2>Tambah Progres Dasar</h2>
        </div>

        <form method="POST" action="">
            <div class="mb-3">
                <label for="user_id" class="form-label">Nama Siswa</label>
                <select class="form-select" id="user_id" name="user_id" required>
                    <option value="" selected disabled>Pilih Nama Siswa</option>
                    <?php while ($row = mysqli_fetch_assoc($result_user)) : ?>
                        <option value="<?= $row['id'] ?>"><?= $row['nama'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                <input type="date" class="form-control" id="tanggal" name="tanggal" required>
            </div>

            <div class="mb-3">
                <label for="catatan" class="form-label">Catatan</label>
                <textarea class="form-control" id="catatan" name="catatan" rows="3" required></textarea>
            </div>

            <button type="submit" class="btn-dashboard">Simpan</button>
        </form>

        <a href="progres_dasar.php" class="btn btn-secondary mt-3">Kembali ke Data Kehadiran</a>
    </div>
</body>

</html>