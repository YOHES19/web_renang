<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

// Tentukan jumlah data per halaman
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Ambil urutan ASC/DESC dari query string atau default DESC
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

// Query untuk mengambil data absen dasar dari tabel kehadiran2
$query = "SELECT k.id, u.username AS nama, k.tanggal, k.status 
          FROM kehadiran2 k 
          JOIN users u ON k.user_id = u.id
          WHERE u.role = 'dasar'
          ORDER BY k.tanggal $sort_order
          LIMIT $start, $limit";
$result = mysqli_query($conn, $query);

// Menghitung total data
$count_query = "SELECT COUNT(*) AS total 
                FROM kehadiran2 k 
                JOIN users u ON k.user_id = u.id 
                WHERE u.role = 'dasar'";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_data / $limit);

// Menangani pengiriman form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = htmlspecialchars($_POST['tanggal']);
    $user_id = $_POST['user_id'];
    $status = $_POST['status'];

    // Cek apakah sudah absen
    $check_query = "SELECT * FROM kehadiran2 WHERE user_id = ? AND tanggal = ?";
    $stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($stmt, "is", $user_id, $tanggal);
    mysqli_stmt_execute($stmt);
    $result_check = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result_check) == 0) {
        // Simpan absensi jika belum ada
        $insert_query = "INSERT INTO kehadiran2 (user_id, tanggal, waktu, status) VALUES (?, ?, NOW(), ?)";
        $stmt = mysqli_prepare($conn, $insert_query);
        mysqli_stmt_bind_param($stmt, "iss", $user_id, $tanggal, $status);
        mysqli_stmt_execute($stmt);
    }

    header("Location: absen_dasar.php?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Data Kehadiran Latihan Dasar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 900px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-dashboard {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: block;
            width: 100%;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-dashboard:hover {
            background: linear-gradient(to right, #0056b3, #0099cc);
        }

        .pagination .page-item.active .page-link {
            background: #007bff;
            color: white;
        }

        .pagination .page-link {
            color: #007bff;
        }

        .pagination .page-link:hover {
            background: #0056b3;
            color: white;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">📝 Data Kehadiran Dasar</div>

        <!-- Form Absen -->
        <form action="" method="POST" class="mb-4">
            <div class="row">
                <div class="col-md-4">
                    <label for="user_id" class="form-label">Nama Siswa</label>
                    <select name="user_id" class="form-select" required>
                        <option value="">Pilih Siswa</option>
                        <?php
                        $siswaQuery = "SELECT id, username FROM users WHERE role = 'dasar'";
                        $siswaResult = mysqli_query($conn, $siswaQuery);
                        while ($siswa = mysqli_fetch_assoc($siswaResult)) {
                            echo "<option value='{$siswa['id']}'>{$siswa['username']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="tanggal" class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select name="status" class="form-select" required>
                        <option value="">Pilih Status</option>
                        <option value="Hadir">Hadir</option>
                        <option value="Tidak Hadir">Tidak Hadir</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Simpan</button>
                </div>
            </div>
        </form>

        <!-- Tombol ke halaman absen -->
        <a href="absen.php" class="btn btn-success mb-3">Absen</a>
        <a href="jumlah_kehadiran.php" class="btn btn-info mb-3 ms-2">📊 Jumlah Kehadiran Siswa</a>


        <!-- Tabel Kehadiran -->
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>
                        Tanggal
                        <a href="?page=<?= $page ?>&sort_order=ASC" class="btn btn-sm btn-outline-light">↑</a>
                        <a href="?page=<?= $page ?>&sort_order=DESC" class="btn btn-sm btn-outline-light">↓</a>
                    </th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = $start + 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$no}</td>";
                    echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                    echo "<td>" . date("d M Y", strtotime($row['tanggal'])) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "<td>
                    <a href='edit_absen.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='hapus_absen.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Yakin ingin menghapus?\")'>Hapus</a>
                </td>";
                    echo "</tr>";
                    $no++;
                }
                if (mysqli_num_rows($result) == 0) {
                    echo "<tr><td colspan='5' class='text-center text-muted'>Belum ada data kehadiran.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Navigasi halaman -->
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($page > 1) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page - 1 ?>&sort_order=<?= $sort_order ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&sort_order=<?= $sort_order ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages) : ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page + 1 ?>&sort_order=<?= $sort_order ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Tombol kembali -->
        <a href="../dashboard.php" class="btn-dashboard mt-3">🏠 Kembali ke Dashboard</a>
    </div>

</body>

</html>