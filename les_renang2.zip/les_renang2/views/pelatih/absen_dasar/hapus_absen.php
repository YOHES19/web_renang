<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Ambil ID absen dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Jika ID tidak valid
if ($id <= 0) {
    header('Location: absen_dasar.php');
    exit();
}

// Hapus data absen
$delete_query = "DELETE FROM kehadiran2 WHERE id = ?";
$stmt = mysqli_prepare($conn, $delete_query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

header('Location: absen_dasar.php?deleted=1');
exit();
