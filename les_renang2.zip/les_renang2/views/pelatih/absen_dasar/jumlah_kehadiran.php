<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}
include '../../../config/config.php';

$query = "SELECT u.username, 
                 SUM(CASE WHEN k.status = 'Hadir' THEN 1 ELSE 0 END) AS total_hadir,
                 SUM(CASE WHEN k.status = 'Tidak Hadir' THEN 1 ELSE 0 END) AS total_tidak_hadir
          FROM kehadiran2 k
          JOIN users u ON k.user_id = u.id
          WHERE u.role = 'dasar'
          GROUP BY u.username
          ORDER BY u.username ASC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Jumlah Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #0066ff, #00ccff);
            color: white;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            margin: auto;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            margin-bottom: 20px;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        .btn-dashboard {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">📊 Jumlah Kehadiran Siswa Dasar</div>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Hadir</th>
                    <th>Tidak Hadir</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$no}</td>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>{$row['total_hadir']}</td>
                        <td>{$row['total_tidak_hadir']}</td>
                      </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>

        <a href="absen_dasar.php" class="btn-dashboard">🔙 Kembali</a>
    </div>
</body>

</html>