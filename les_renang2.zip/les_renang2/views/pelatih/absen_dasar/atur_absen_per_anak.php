<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tanggal'], $_POST['status'])) {
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Cek apakah data kehadiran sudah ada
    $cek = mysqli_query($conn, "SELECT * FROM kehadiran WHERE user_id='$user_id' AND tanggal='$tanggal'");
    if (mysqli_num_rows($cek) > 0) {
        // Jika sudah ada, update status
        mysqli_query($conn, "UPDATE kehadiran SET status='$status' WHERE user_id='$user_id' AND tanggal='$tanggal'");
    } else {
        // Jika belum ada, insert data
        mysqli_query($conn, "INSERT INTO kehadiran (user_id, tanggal, status) VALUES ('$user_id', '$tanggal', '$status')");
    }

    echo "<script>alert('Kehadiran berhasil disimpan!'); window.location.href='kehadiran.php';</script>";
    exit();
}

// Ambil data siswa
$siswaQuery = mysqli_query($conn, "SELECT username FROM users WHERE id='$user_id'");
$siswa = mysqli_fetch_assoc($siswaQuery);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Atur Absen Per Anak</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            min-height: 100vh;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: white;
            color: black;
            padding: 30px;
            border-radius: 15px;
            max-width: 600px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 25px;
            color: #007bff;
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            padding: 10px 20px;
        }

        .btn-custom:hover {
            background: #00aaff;
        }

        .btn-back {
            background-color: #6c757d;
            color: white;
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: bold;
        }

        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Atur Kehadiran Siswa</div>
        <form action="" method="post">
            <div class="mb-3">
                <label class="form-label">Nama Siswa</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($siswa['username']) ?>" readonly>
            </div>
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" name="tanggal" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Status Kehadiran</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" id="hadir" value="Hadir" required>
                    <label class="form-check-label" for="hadir">Hadir</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" id="tidak_hadir" value="Tidak Hadir" required>
                    <label class="form-check-label" for="tidak_hadir">Tidak Hadir</label>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-4">
                <a href="kehadiran.php" class="btn btn-back">Kembali</a>
                <button type="submit" class="btn btn-custom">Simpan</button>
            </div>
        </form>
    </div>
</body>

</html>