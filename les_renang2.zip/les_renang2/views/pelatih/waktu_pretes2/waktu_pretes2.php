<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

function getWaktuPretes($conn, $limit, $offset)
{
    $sql = "SELECT wp.*, u.nama as user_nama, u.role as user_role 
            FROM waktu_pretes2 wp
            JOIN users u ON wp.user_id = u.id
            ORDER BY wp.tanggal DESC 
            LIMIT $limit OFFSET $offset";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

function countWaktuPretes($conn)
{
    $sql = "SELECT COUNT(*) as total FROM waktu_pretes2";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}

function getUsers($conn)
{
    $sql = "SELECT id, nama, role FROM users WHERE role IN ('user', 'selam')";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$waktu_pretes = getWaktuPretes($conn, $limit, $offset);
$total = countWaktuPretes($conn);
$total_pages = ceil($total / $limit);
$users = getUsers($conn);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Tambah Pretes - Les Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(to right, rgb(10, 255, 173), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        .card-header {
            background-color: #007bff;
            color: white;
        }

        .table th,
        .table td {
            text-align: center;
            vertical-align: middle;
        }

        .pagination {
            justify-content: center;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <a href="../dashboard.php" class="btn btn-secondary mb-4">Kembali ke Dashboard</a>

        <!-- Form Tambah Pretes -->
        <div class="card mb-5">
            <div class="card-header text-center">
                <h4>Tambah Data Pretes 100 M</h4>
            </div>
            <div class="card-body">
                <form action="proses_tambah_pretes.php" method="POST">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Nama Peserta</label>
                            <select class="form-select" name="user_id" required>
                                <option value="">Pilih Nama</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>"><?= $user['nama'] ?> (<?= ucfirst($user['role']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Tanggal</label>
                            <input type="date" class="form-control" name="tanggal" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Waktu</label>
                            <input type="time" class="form-control" name="waktu" required>
                        </div>
                    </div>

                    <div class="row g-3 mt-3">
                        <div class="col-md-3">
                            <label class="form-label">Gaya Dada (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_dada_100m" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Gaya Bebas (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_bebas_100m" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Gaya Kupu-Kupu (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_kupu_kupu_100m" placeholder="00:00:00" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Gaya Punggung (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_punggung_100m" placeholder="00:00:00" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center mt-4">
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-plus-lg"></i> Tambah Pretes
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tabel Hasil Pretes -->
        <div class="card">
            <div class="card-header text-center">
                <h4>Hasil Pretes 100 M</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-center align-middle">
                        <thead class="table-primary">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Role</th>
                                <th>Tanggal</th>
                                <th>Waktu</th>
                                <th>Dada (100m)</th>
                                <th>Bebas (100m)</th>
                                <th>Kupu-Kupu (100m)</th>
                                <th>Punggung (100m)</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = $offset + 1; ?>
                            <?php foreach ($waktu_pretes as $row): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $row['user_nama'] ?></td>
                                    <td><?= ucfirst($row['user_role']) ?></td>
                                    <td><?= $row['tanggal'] ?></td>
                                    <td><?= $row['waktu'] ?></td>
                                    <td><?= $row['waktu_gaya_dada_100m'] ?></td>
                                    <td><?= $row['waktu_gaya_bebas_100m'] ?></td>
                                    <td><?= $row['waktu_gaya_kupu_kupu_100m'] ?></td>
                                    <td><?= $row['waktu_gaya_punggung_100m'] ?></td>
                                    <td>
                                        <a href="edit_pretes.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm mb-1">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </a>
                                        <a href="hapus_pretes.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin hapus data ini?');">
                                            <i class="bi bi-trash"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav>
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    </div>
</body>

</html>