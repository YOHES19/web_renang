<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $waktu = $_POST['waktu'];
    $dada = $_POST['waktu_gaya_dada_100m'];
    $bebas = $_POST['waktu_gaya_bebas_100m'];
    $kupu = $_POST['waktu_gaya_kupu_kupu_100m'];
    $punggung = $_POST['waktu_gaya_punggung_100m'];

    $stmt = $conn->prepare("INSERT INTO waktu_pretes2 (user_id, tanggal, waktu, waktu_gaya_dada_100m, waktu_gaya_bebas_100m, waktu_gaya_kupu_kupu_100m, waktu_gaya_punggung_100m) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $user_id, $tanggal, $waktu, $dada, $bebas, $kupu, $punggung);

    if ($stmt->execute()) {
        header("Location: waktu_pretes2.php?success=1");
        exit();
    } else {
        echo "Gagal menyimpan data: " . $stmt->error;
    }

    $stmt->close();
}
