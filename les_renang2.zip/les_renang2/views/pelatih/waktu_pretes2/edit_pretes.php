<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Proses update jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $waktu = $_POST['waktu'];
    $dada = $_POST['waktu_gaya_dada_100m'];
    $bebas = $_POST['waktu_gaya_bebas_100m'];
    $kupu = $_POST['waktu_gaya_kupu_kupu_100m'];
    $punggung = $_POST['waktu_gaya_punggung_100m'];

    $sql = "UPDATE waktu_pretes2 SET 
            user_id='$user_id', tanggal='$tanggal', waktu='$waktu',
            waktu_gaya_dada_100m='$dada', waktu_gaya_bebas_100m='$bebas',
            waktu_gaya_kupu_kupu_100m='$kupu', waktu_gaya_punggung_100m='$punggung'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header('Location: waktu_pretes2.php');
        exit();
    } else {
        $error = "Gagal update data: " . $conn->error;
    }
}

// Ambil data berdasarkan ID
if (!isset($_GET['id'])) {
    echo "ID tidak ditemukan!";
    exit();
}

$id = $_GET['id'];
$sql = "SELECT * FROM waktu_pretes2 WHERE id = $id";
$result = $conn->query($sql);
$data = $result->fetch_assoc();

if (!$data) {
    echo "Data tidak ditemukan!";
    exit();
}

// Ambil user
$users = $conn->query("SELECT id, nama FROM users WHERE role = 'user'")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Edit Pretes - Les Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(to right, rgb(10, 255, 173), rgb(160, 212, 247));
            font-family: 'Arial', sans-serif;
        }

        .card-header {
            background-color: #007bff;
            color: white;
        }

        .table th,
        .table td {
            text-align: center;
            vertical-align: middle;
        }

        .pagination {
            justify-content: center;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <a href="waktu_pretes2.php" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Kembali</a>

        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Edit Data Pretes</h4>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>
                <form method="POST" action="">
                    <input type="hidden" name="id" value="<?= $data['id'] ?>">

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Nama Peserta</label>
                            <select class="form-select" name="user_id" required>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>" <?= $user['id'] == $data['user_id'] ? 'selected' : '' ?>>
                                        <?= $user['nama'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Tanggal</label>
                            <input type="date" name="tanggal" class="form-control" value="<?= $data['tanggal'] ?>" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Waktu</label>
                            <input type="time" name="waktu" class="form-control" value="<?= $data['waktu'] ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-3">
                            <label class="form-label">Dada (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_dada_100m" value="<?= $data['waktu_gaya_dada_100m'] ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Bebas (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_bebas_100m" value="<?= $data['waktu_gaya_bebas_100m'] ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Kupu-Kupu (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_kupu_kupu_100m" value="<?= $data['waktu_gaya_kupu_kupu_100m'] ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Punggung (100m)</label>
                            <input type="text" class="form-control" name="waktu_gaya_punggung_100m" value="<?= $data['waktu_gaya_punggung_100m'] ?>" required>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>