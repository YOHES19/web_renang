<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

$id = $_GET['id'];

$sql = "DELETE FROM waktu_pretes2 WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header('Location: tambah_pretes.php');
} else {
    echo "Gagal menghapus data: " . $conn->error;
}
