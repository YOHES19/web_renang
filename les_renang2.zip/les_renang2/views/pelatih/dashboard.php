<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}
include '../../config/config.php';

// Ambil data user dari database
$user_id = $_SESSION['user_id'];
$query = "SELECT nama FROM users WHERE id = '$user_id' AND role = 'pelatih'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
$nama = $user ? htmlspecialchars($user['nama']) : 'Pelatih';

// Menutup koneksi
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pelatih</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            display: flex;
            background-color: #f8f9fa;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, rgb(5, 206, 179), rgb(64, 155, 245));
            color: white;
            padding: 20px;
            position: fixed;
            transition: transform 0.3s ease-in-out;


        }

        .sidebar.hidden {
            transform: translateX(-100%);
        }

        .sidebar a {
            color: #ffffff;
            text-decoration: none;
            display: block;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 10px;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: rgb(245, 64, 94);
        }

        .content {
            margin-left: 300px;
            padding: 30px;
            width: 100%;
            transition: margin-left 0.3s ease-in-out;
        }

        .content.full-width {
            margin-left: 0;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 213px;
            background: rgb(26, 135, 245);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000;
            transition: left 0.3s ease-in-out;
        }

        .sidebar.hidden+.toggle-btn {
            left: 20px;
        }

        .header {
            background: linear-gradient(135deg, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
        }

        .carousel img {
            height: 450px;
            object-fit: cover;
            border-radius: 10px;
        }

        .carousel-container {
            margin-top: 30px;
        }
    </style>
</head>

<body>
    <div class="sidebar" id="sidebar">
        <h4 class="text-white text-center mb-4">Pelatih</h4>
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="../pelatih/kehadiran/kehadiran.php">📝 Absen Kehadiran</a>
        <a href="../pelatih/pantau_progres/progres.php">📊 Progres Atlet</a>
        <a href="../pelatih/waktu_pretes/waktu_pretes1.php">📋 waktu Pretes 50m</a>
        <a href="../pelatih/waktu_pretes2/waktu_pretes2.php">📋 Waktu Pretes 100 m</a>
        <a href="../pelatih/absen_dasar/absen_dasar.php">📅 Absen Dasar</a>
        <a href="../pelatih/progres_dasar/progres_dasar.php">📈 Progres Dasar</a>
        <a href="../pelatih/kehadiran_privat8/laporan_kehadiran.php">🗓️ Absen Privat 8</a>
        <a href="../pelatih/kehadiran_privat12/laporan_kehadiran.php">🗓️ Absen Privat 12</a>

        <a href="../../logout.php">🚪 Logout</a>
    </div>

    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>

    <div class="content" id="content">
        <div class="header">
            <h1>Selamat Datang Pelatih <?= $nama ?> 🏊</h1>
        </div>

        <!-- Carousel Foto -->
        <div class="carousel-container">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="../admin/1.jpeg" class="d-block w-100" alt="Foto 1">
                    </div>
                    <div class="carousel-item">
                        <img src="../admin/2.jpeg" class="d-block w-100" alt="Foto 2">
                    </div>
                    <div class="carousel-item">
                        <img src="../admin/3.jpeg" class="d-block w-100" alt="Foto 3">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('content');
            const toggleBtn = document.querySelector('.toggle-btn');

            sidebar.classList.toggle('hidden');
            content.classList.toggle('full-width');
        }
    </script>
</body>

</html>