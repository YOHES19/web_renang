<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Cek apakah parameter ID ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data kehadiran dari database berdasarkan ID
    $query = "DELETE FROM kehadiran WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        // Redirect ke halaman kehadiran setelah berhasil menghapus data
        header('Location: kehadiran.php?status=success');
    } else {
        // Jika gagal menghapus data, tampilkan pesan error
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "ID tidak ditemukan!";
}

mysqli_close($conn);
