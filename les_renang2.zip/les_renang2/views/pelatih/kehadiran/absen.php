<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tanggal'])) {
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);

    foreach ($_POST['kehadiran'] as $user_id => $status) {
        $status = mysqli_real_escape_string($conn, $status);
        $query = "INSERT INTO kehadiran (user_id, tanggal, status) VALUES ('$user_id', '$tanggal', '$status')";
        mysqli_query($conn, $query);
    }
}

$siswaResult = mysqli_query($conn, "SELECT id, username FROM users WHERE role = 'user' OR role = 'selam'");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absen Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding: 40px 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 1000px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        table {
            border-radius: 10px;
            overflow: hidden;
        }

        table thead {
            background: linear-gradient(to right, #007bff, #00c3ff);
            color: white;
        }

        table tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
        }

        .btn-custom:hover {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            border-radius: 10px;
        }

        .btn-back {
            background-color: #6c757d;
            color: white;
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: bold;
        }

        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Catat Kehadiran Siswa</div>

        <form action="" method="post" class="mb-4">
            <div class="row mb-4">
                <div class="col-md-6">
                    <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                    <input type="date" name="tanggal" class="form-control" required>
                </div>
                <div class="col-md-6 text-end mt-4">
                    <a href="../kehadiran/kehadiran.php" class="btn btn-back">Kembali ke Daftar Kehadiran</a>
                </div>
            </div>

            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <th>Hadir</th>
                        <th>Tidak Hadir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    while ($siswa = mysqli_fetch_assoc($siswaResult)) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($siswa['username']) ?></td>
                            <td>
                                <input type="radio" name="kehadiran[<?= $siswa['id'] ?>]" value="Hadir" required>
                            </td>
                            <td>
                                <input type="radio" name="kehadiran[<?= $siswa['id'] ?>]" value="Tidak Hadir" required>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn-custom">Simpan Kehadiran</button>
            </div>
        </form>
    </div>
</body>

</html>