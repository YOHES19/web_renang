<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Proses simpan data kehadiran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $status = $_POST['status'];

    $check = mysqli_query($conn, "SELECT * FROM kehadiran WHERE user_id = '$user_id' AND tanggal = '$tanggal'");
    if (mysqli_num_rows($check) == 0) {
        mysqli_query($conn, "INSERT INTO kehadiran (user_id, tanggal, status) VALUES ('$user_id', '$tanggal', '$status')");
    }
}

$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$result = mysqli_query($conn, "SELECT k.id, u.username, k.tanggal, k.status 
                               FROM kehadiran k 
                               JOIN users u ON k.user_id = u.id 
                               ORDER BY k.tanggal DESC 
                               LIMIT $limit OFFSET $offset");

$totalResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM kehadiran");
$totalRow = mysqli_fetch_assoc($totalResult);
$totalData = $totalRow['total'];
$totalPages = ceil($totalData / $limit);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Catat Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 1000px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            margin-bottom: 20px;
        }

        .btn-custom {
            background: linear-gradient(to right, #1e90ff, #00bfff);
            color: white;
            border-radius: 10px;
            font-weight: bold;
            border: none;
            transition: 0.3s;
            padding: 8px 16px;
            font-size: 14px;
        }

        .btn-custom:hover {
            opacity: 0.85;
        }

        .button-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .pagination .page-link {
            color: #1e90ff;
        }

        .pagination .page-item.active .page-link {
            background-color: rgb(255, 255, 255);
            border-color: rgb(136, 194, 252);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Catat Kehadiran</div>

        <div class="text-end mb-3">
            <a href="../dashboard.php" class="btn-custom">Kembali ke Dashboard</a>
        </div>

        <!-- Form Tambah Kehadiran -->
        <form action="" method="post" class="mb-4">
            <div class="row">
                <div class="col-md-4">
                    <label for="user_id" class="form-label">Nama Siswa</label>
                    <select name="user_id" class="form-select" required>
                        <option value="">Pilih Siswa</option>
                        <?php
                        $siswaResult = mysqli_query($conn, "SELECT id, username, role FROM users WHERE role = 'user' OR role = 'selam'");
                        while ($siswa = mysqli_fetch_assoc($siswaResult)) {
                            echo "<option value='{$siswa['id']}'>{$siswa['username']} ({$siswa['role']})</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="tanggal" class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" required>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select name="status" class="form-select" required>
                        <option value="">Pilih Status</option>
                        <option value="Hadir">Hadir</option>
                        <option value="Tidak Hadir">Tidak Hadir</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn-custom w-100">Simpan</button>
                </div>
            </div>
        </form>

        <!-- Tombol Tambahan -->
        <div class="button-container">
            <a href="absen.php" class="btn-custom">Absen</a>
            <button class="btn-custom" onclick="savePDF()">Save as PDF</button>
        </div>

        <!-- Tabel Kehadiran -->
        <div class="table-responsive">
            <table class="table table-bordered" id="attendanceTable">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Siswa</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = $offset + 1;
                    while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= htmlspecialchars($row['username']) ?></td>
                            <td><?= htmlspecialchars($row['tanggal']) ?></td>
                            <td><?= htmlspecialchars($row['status']) ?></td>
                            <td>
                                <a href="edit_kehadiran.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="hapus_kehadiran.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <nav>
            <ul class="pagination justify-content-center">
                <li class="page-item <?= ($page == 1) ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                    <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= ($page == $totalPages) ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                </li>
            </ul>
        </nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.14/jspdf.plugin.autotable.js"></script>
    <script>
        function savePDF() {
            const {
                jsPDF
            } = window.jspdf;
            const doc = new jsPDF();
            const rows = [];
            const table = document.getElementById("attendanceTable");
            const rowsHTML = table.querySelectorAll("tbody tr");

            const headers = [];
            table.querySelectorAll("thead th").forEach((th, index) => {
                if (index !== 4) {
                    headers.push(th.textContent.trim());
                }
            });

            rowsHTML.forEach((row) => {
                const rowData = [];
                const cells = row.querySelectorAll("td");
                cells.forEach((cell, index) => {
                    if (index !== 4) {
                        rowData.push(cell.textContent.trim());
                    }
                });
                rows.push(rowData);
            });

            doc.autoTable({
                head: [headers],
                body: rows,
            });

            doc.save("kehadiran.pdf");
        }
    </script>
</body>

</html>