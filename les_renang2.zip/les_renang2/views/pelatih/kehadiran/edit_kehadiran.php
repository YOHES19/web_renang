<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

if (isset($_GET['id'])) {
    $id_kehadiran = mysqli_real_escape_string($conn, $_GET['id']);
    $query = "SELECT k.id, k.user_id, k.tanggal, k.status, u.username 
              FROM kehadiran k 
              JOIN users u ON k.user_id = u.id 
              WHERE k.id = '$id_kehadiran'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 1) {
        $kehadiran = mysqli_fetch_assoc($result);
    } else {
        echo "Data kehadiran tidak ditemukan.";
        exit();
    }
} else {
    echo "ID kehadiran tidak ditemukan.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['status'])) {
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $updateQuery = "UPDATE kehadiran SET status = '$status' WHERE id = '$id_kehadiran'";
    if (mysqli_query($conn, $updateQuery)) {
        header("Location: kehadiran.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding: 40px 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 600px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 15px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            margin-bottom: 25px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .form-label {
            font-weight: bold;
        }

        .form-control,
        .form-select {
            border-radius: 10px;
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
        }

        .btn-custom:hover {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            opacity: 0.9;
        }

        .btn-back {
            background-color: #6c757d;
            color: white;
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: bold;
            margin-top: 10px;
        }

        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="header">Edit Kehadiran Siswa</div>
        <form method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Nama Siswa</label>
                <input type="text" class="form-control" id="username" value="<?= htmlspecialchars($kehadiran['username']) ?>" readonly>
            </div>

            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                <input type="date" class="form-control" id="tanggal" value="<?= htmlspecialchars($kehadiran['tanggal']) ?>" readonly>
            </div>

            <div class="mb-3">
                <label for="status" class="form-label">Status Kehadiran</label>
                <select name="status" class="form-select" required>
                    <option value="Hadir" <?= $kehadiran['status'] == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                    <option value="Tidak Hadir" <?= $kehadiran['status'] == 'Tidak Hadir' ? 'selected' : '' ?>>Tidak Hadir</option>
                </select>
            </div>

            <button type="submit" class="btn btn-custom">Update Kehadiran</button>
            <a href="../kehadiran/kehadiran.php" class="btn btn-back">Kembali ke Daftar Kehadiran</a>
        </form>
    </div>

</body>

</html>