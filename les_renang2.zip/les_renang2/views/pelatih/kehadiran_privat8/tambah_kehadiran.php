<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Ambil data user dengan role 'user' atau 'selam' untuk dropdown
$query_user = "SELECT id, username, role FROM users WHERE role = 'privat8'";
$result_user = mysqli_query($conn, $query_user);

// Proses untuk menambahkan kehadiran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tanggal = $_POST['tanggal'];
    $status = $_POST['status'];

    // Query untuk menyimpan data kehadiran
    $query_insert = "INSERT INTO absenprivat8 (user_id, tanggal, status) 
                     VALUES ('$user_id', '$tanggal', '$status')";

    if (mysqli_query($conn, $query_insert)) {
        echo "<script>alert('Data kehadiran berhasil ditambahkan!'); window.location.href='laporan_kehadiran.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data kehadiran: " . mysqli_error($conn) . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kehadiran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(138, 1, 165), #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 700px;
            width: 100%;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .card-header {
            background: linear-gradient(to right, rgb(138, 1, 165), #00c3ff);
            color: white;
            font-weight: bold;
            font-size: 22px;
            padding: 15px;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(138, 1, 165), #00c3ff);
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 10px;
            width: 100%;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background: linear-gradient(to right, rgb(138, 1, 165), #0099cc);
        }

        .btn-secondary-custom {
            background-color: #6c757d;
            border-color: #6c757d;
            border-radius: 10px;
        }

        .btn-secondary-custom:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                Tambah Kehadiran
            </div>
            <div class="card-body">
                <form action="tambah_kehadiran.php" method="POST">
                    <div class="mb-3">
                        <label for="user_id" class="form-label">Nama Siswa</label>
                        <select class="form-select" id="user_id" name="user_id" required>
                            <option value="">Pilih Siswa</option>
                            <?php while ($row_user = mysqli_fetch_assoc($result_user)) { ?>
                                <option value="<?= $row_user['id'] ?>">
                                    <?= $row_user['username'] ?> (<?= $row_user['role'] ?>)
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status Kehadiran</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="Hadir">Hadir</option>
                            <option value="Tidak Hadir">Tidak Hadir</option>
                            <option value="Sakit">Sakit</option>
                            <option value="Izin">Izin</option>
                        </select>
                    </div>

                    <div class="d-grid mb-2">
                        <button type="submit" class="btn btn-custom">Simpan Kehadiran</button>
                    </div>
                    <a href="laporan_kehadiran.php" class="btn btn-secondary-custom w-100">Kembali</a>
                </form>
            </div>
        </div>
    </div>
</body>

</html>