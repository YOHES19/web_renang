<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

// Menyertakan file konfigurasi koneksi database
include '../../../config/config.php';  // Pastikan path sudah benar

// Mendapatkan ID dari URL
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Jika ID tidak ada, arahkan kembali ke laporan
if ($id == null) {
    header('Location: laporan_kehadiran.php');
    exit();
}

// Ambil data dari tabel absenprivat8
$query = "SELECT absenprivat8.id, users.username, absenprivat8.tanggal, absenprivat8.status 
          FROM absenprivat8 
          JOIN users ON absenprivat8.user_id = users.id";
$result = mysqli_query($conn, $query);

// Menangani jika data tidak ditemukan
if (mysqli_num_rows($result) == 0) {
    die("Data tidak ditemukan.");
}

// Ambil data kehadiran untuk ditampilkan di form
$row = mysqli_fetch_assoc($result);
$current_status = $row['status']; // Status kehadiran saat ini
$current_date = $row['tanggal']; // Tanggal kehadiran saat ini

// Proses update data ketika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_status = $_POST['status']; // Status yang baru
    $new_date = $_POST['tanggal']; // Tanggal yang baru

    // Update data kehadiran
    $update_query = "UPDATE absenprivat8 SET status = '$new_status', tanggal = '$new_date' WHERE id = '$id'";
    if (mysqli_query($conn, $update_query)) {
        header('Location: laporan_kehadiran.php'); // Redirect ke laporan setelah berhasil update
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kehadiran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(138, 1, 165), #00ccff);
            color: white;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 700px;
            width: 100%;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .card-header {
            background: linear-gradient(to right, rgb(138, 1, 165), #00c3ff);
            color: white;
            font-weight: bold;
            font-size: 22px;
            padding: 15px;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-custom {
            background: linear-gradient(to right, rgb(138, 1, 165), #00c3ff);
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 10px;
            width: 100%;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background: linear-gradient(to right, rgb(138, 1, 165), #0099cc);
        }

        .btn-secondary-custom {
            background-color: #6c757d;
            border-color: #6c757d;
            border-radius: 10px;
            width: 100%;
        }

        .btn-secondary-custom:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Card untuk form edit kehadiran -->
        <div class="card">
            <div class="card-header">
                Edit Kehadiran
            </div>
            <div class="card-body">
                <!-- Form untuk edit kehadiran -->
                <form method="POST">
                    <div class="mb-3">
                        <label for="status" class="form-label">Status Kehadiran</label>
                        <select class="form-select" name="status" id="status" required>
                            <option value="Hadir" <?= $current_status == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                            <option value="Tidak Hadir" <?= $current_status == 'Tidak Hadir' ? 'selected' : '' ?>>Tidak Hadir</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Kehadiran</label>
                        <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $current_date ?>" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-custom">Update Kehadiran</button>
                        <a href="laporan_kehadiran.php" class="btn btn-secondary-custom">Kembali ke Laporan</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>