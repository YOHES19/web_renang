<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'pelatih') {
    header('Location: ../login.php');
    exit();
}

include '../../../config/config.php';

// Proses penghapusan data jika tombol hapus ditekan
if (isset($_GET['hapus_id'])) {
    $hapus_id = $_GET['hapus_id'];
    $delete_sql = "DELETE FROM progres WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $hapus_id);
    $stmt->execute();
    header("Location: progres.php");
    exit();
}

// Ambil data progres
$sql = "SELECT progres.id, progres.user_id, progres.tanggal, progres.catatan, users.username 
        FROM progres 
        JOIN users ON progres.user_id = users.id 
        ORDER BY progres.tanggal DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progres Latihan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            color: black;
            border-radius: 15px;
            padding: 30px;
            max-width: 900px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            padding: 20px;
            border-radius: 10px;
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            margin-bottom: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-progres,
        .btn-dashboard {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
        }

        .btn-progres:hover,
        .btn-dashboard:hover {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
        }

        table {
            margin-top: 20px;
            border-radius: 10px;
            overflow: hidden;
        }

        thead {
            background: linear-gradient(to right, rgb(71, 250, 226), rgb(64, 155, 245));
            color: white;
        }

        tbody tr:hover {
            background: rgba(0, 123, 255, 0.1);
            transition: 0.3s;
        }

        .btn-edit,
        .btn-delete {
            padding: 5px 10px;
            font-size: 14px;
            border-radius: 30px;
            color: white;
            text-decoration: none;
        }

        .btn-edit {
            background-color: #ffc107;
        }

        .btn-delete {
            background-color: #dc3545;
        }

        .text-center-empty {
            text-align: center;
            color: gray;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">Progres Latihan Siswa</div>

        <div class="d-flex justify-content-between mb-3">
            <a href="../dashboard.php" class="btn-dashboard">🏠 Kembali ke Dashboard</a>
            <a href="tambah_progres.php" class="btn-progres">➕ Tambah Progres</a>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Tanggal</th>
                    <th>Catatan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $no = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$no}</td>
                                <td>{$row['username']}</td>
                                <td>" . date('d-m-Y', strtotime($row['tanggal'])) . "</td>
                                <td>{$row['catatan']}</td>
                                <td>
                                    <a href='edit_progres.php?id={$row['id']}' class='btn-edit'>✏️ Edit</a>
                                    <a href='?hapus_id={$row['id']}' onclick='return confirm(\"Yakin ingin menghapus data ini?\")' class='btn-delete'>🗑️ Hapus</a>
                                </td>
                              </tr>";
                        $no++;
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center-empty'>Tidak ada data progres tersedia.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>

<?php $conn->close(); ?>