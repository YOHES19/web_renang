<?php
include '../config/config.php'; // Koneksi database

// Cek jika ada permintaan pembayaran dari form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $jumlah = $_POST['jumlah'];
    $tanggal = date("Y-m-d"); // Tanggal transaksi

    // Simpan pembayaran ke database
    $query = "INSERT INTO pembayaran (user_id, jumlah, status, tanggal) VALUES (?, ?, 'pending', ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ids", $user_id, $jumlah, $tanggal);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Pembayaran berhasil, menunggu konfirmasi.'); window.location.href='../views/user/pembayaran_user.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan saat melakukan pembayaran.'); window.history.back();</script>";
    }
    mysqli_stmt_close($stmt);
}

// Jika admin ingin mengonfirmasi pembayaran
if (isset($_GET['konfirmasi_id'])) {
    $id = $_GET['konfirmasi_id'];
    $updateQuery = "UPDATE pembayaran SET status='lunas' WHERE id=?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Pembayaran telah dikonfirmasi.'); window.location.href='../views/admin/pembayaran.php';</script>";
    } else {
        echo "<script>alert('Gagal mengonfirmasi pembayaran.'); window.history.back();</script>";
    }
    mysqli_stmt_close($stmt);
}
