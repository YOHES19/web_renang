<?php
$host = "localhost"; // Host database
$user = "root"; // Username database
$password = ""; // Password database (kosong jika menggunakan XAMPP)
$database = "renang"; // Nama database

// Koneksi ke database
$conn = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
