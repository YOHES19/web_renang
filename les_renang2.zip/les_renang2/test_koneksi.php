<?php
include 'config/config.php';
if ($conn) {
    echo "Koneksi berhasil!";
} else {
    echo "Koneksi gagal!";
}
