<?php
// models/users.php
include '../../../config/config.php';  // Pastikan path-nya benar

// Create: Menambahkan user baru
function createUser($username, $password, $role)
{
    global $conn;
    $password_hash = password_hash($password, PASSWORD_BCRYPT); // Enkripsi password
    $query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sss", $username, $password_hash, $role);
    return mysqli_stmt_execute($stmt);
}

// Read: Mengambil data user berdasarkan ID
function getUserById($user_id)
{
    global $conn;
    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Update: Mengupdate data user
function updateUser($user_id, $username, $password, $role)
{
    global $conn;
    $password_hash = password_hash($password, PASSWORD_BCRYPT); // Enkripsi password
    $query = "UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sssi", $username, $password_hash, $role, $user_id);
    return mysqli_stmt_execute($stmt);
}

// Delete: Menghapus user
function deleteUser($user_id)
{
    global $conn;
    $query = "DELETE FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    return mysqli_stmt_execute($stmt);
}

// Fungsi untuk memeriksa username dan password saat login
function loginUser($username, $password)
{
    global $conn;
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        return $user;
    } else {
        return false;
    }
}

// Fungsi untuk mengambil semua data user
function getAllUsers()
{
    global $conn;
    $query = "SELECT * FROM users";  // Pastikan tabel yang digunakan adalah 'users'
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Query Error: ' . mysqli_error($conn));
    }

    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}
