<?php
include '../../../config/config.php';  // Pastikan path-nya benar

// Create: Menambahkan pelatih baru
function createPelatih($nama, $spesialisasi, $kontak)
{
    global $conn;
    $query = "INSERT INTO pelatih (nama, spesialisasi, kontak) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sss", $nama, $spesialisasi, $kontak);
    return mysqli_stmt_execute($stmt);
}

// Read: Mengambil data pelatih berdasarkan ID
function getPelatihById($pelatih_id)
{
    global $conn;
    $query = "SELECT * FROM pelatih WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $pelatih_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Update: Mengupdate data pelatih
function updatePelatih($pelatih_id, $nama, $spesialisasi, $kontak)
{
    global $conn;
    $query = "UPDATE pelatih SET nama = ?, spesialisasi = ?, kontak = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sssi", $nama, $spesialisasi, $kontak, $pelatih_id);
    return mysqli_stmt_execute($stmt);
}

// Delete: Menghapus pelatih
function deletePelatih($pelatih_id)
{
    global $conn;
    $query = "DELETE FROM pelatih WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $pelatih_id);
    return mysqli_stmt_execute($stmt);
}

// Read All: Mengambil seluruh data pelatih
function getAllPelatih()
{
    global $conn;
    $query = "SELECT * FROM pelatih";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}
