<?php
include '../config/config.php';

// Create: Menambahkan pembayaran baru
function createPembayaran($user_id, $jumlah, $status = 'pending')
{
    global $conn;
    $tanggal = date("Y-m-d");
    $query = "INSERT INTO pembayaran (user_id, jumlah, status, tanggal) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "idss", $user_id, $jumlah, $status, $tanggal);
    return mysqli_stmt_execute($stmt);
}

// Read: Mengambil semua pembayaran berdasarkan user ID
function getPembayaranByUserId($user_id)
{
    global $conn;
    $query = "SELECT * FROM pembayaran WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Read: Mengambil seluruh pembayaran untuk admin
function getAllPembayaran()
{
    global $conn;
    $query = "SELECT * FROM pembayaran";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Update: Mengupdate status pembayaran
function updatePembayaranStatus($pembayaran_id, $status)
{
    global $conn;
    $query = "UPDATE pembayaran SET status = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "si", $status, $pembayaran_id);
    return mysqli_stmt_execute($stmt);
}

// Delete: Menghapus pembayaran
function deletePembayaran($pembayaran_id)
{
    global $conn;
    $query = "DELETE FROM pembayaran WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $pembayaran_id);
    return mysqli_stmt_execute($stmt);
}
