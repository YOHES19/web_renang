-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2025 at 05:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `renang`
--

-- --------------------------------------------------------

--
-- Table structure for table `absenprivat8`
--

CREATE TABLE `absenprivat8` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('Hadir','Tidak Hadir','Izin','Sakit') NOT NULL DEFAULT 'Hadir'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `absenprivat8`
--

INSERT INTO `absenprivat8` (`id`, `user_id`, `tanggal`, `status`) VALUES
(1, 12, '2025-04-05', 'Hadir'),
(2, 12, '2025-04-05', 'Hadir');

-- --------------------------------------------------------

--
-- Table structure for table `absenprivat12`
--

CREATE TABLE `absenprivat12` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('Hadir','Tidak Hadir','Izin','Sakit') NOT NULL DEFAULT 'Hadir'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `absenprivat12`
--

INSERT INTO `absenprivat12` (`id`, `user_id`, `tanggal`, `status`) VALUES
(1, 13, '2025-04-05', 'Tidak Hadir'),
(2, 13, '2025-04-06', 'Hadir');

-- --------------------------------------------------------

--
-- Table structure for table `kehadiran`
--

CREATE TABLE `kehadiran` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('Hadir','Tidak Hadir') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kehadiran`
--

INSERT INTO `kehadiran` (`id`, `user_id`, `tanggal`, `status`) VALUES
(1, 1, '2025-04-05', 'Tidak Hadir');

-- --------------------------------------------------------

--
-- Table structure for table `kehadiran2`
--

CREATE TABLE `kehadiran2` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('Hadir','Tidak Hadir','Izin') DEFAULT 'Hadir',
  `waktu` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pelatih`
--

CREATE TABLE `pelatih` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `spesialisasi` varchar(100) NOT NULL,
  `kontak` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelatih`
--

INSERT INTO `pelatih` (`id`, `nama`, `spesialisasi`, `kontak`, `created_at`) VALUES
(1, 'yoga', 'prestasi', '098678426475', '2025-04-04 09:23:13');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `jumlah` decimal(10,2) NOT NULL,
  `status` enum('lunas','belum lunas') NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran2`
--

CREATE TABLE `pembayaran2` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `status` enum('Lunas','Belum Lunas') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `privat8`
--

CREATE TABLE `privat8` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `status` enum('Belum Bayar','Sudah Bayar') NOT NULL DEFAULT 'Belum Bayar'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `privat8`
--

INSERT INTO `privat8` (`id`, `user_id`, `tanggal`, `jumlah`, `status`) VALUES
(1, 12, '2025-04-05', 200000, 'Belum Bayar'),
(3, 12, '2025-04-06', 100000, 'Sudah Bayar');

-- --------------------------------------------------------

--
-- Table structure for table `privat12`
--

CREATE TABLE `privat12` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `status` enum('Belum Bayar','Sudah Bayar') NOT NULL DEFAULT 'Belum Bayar'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `privat12`
--

INSERT INTO `privat12` (`id`, `user_id`, `tanggal`, `jumlah`, `status`) VALUES
(2, 13, '2025-04-07', 200000, 'Sudah Bayar');

-- --------------------------------------------------------

--
-- Table structure for table `progres`
--

CREATE TABLE `progres` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `catatan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `progres2`
--

CREATE TABLE `progres2` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `catatan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `role` enum('admin','pelatih','user','dasar','privat8','privat12') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama`, `role`, `created_at`) VALUES
(1, 'yoga', '$2y$10$iwdFZvC1O2xykJ4IYC2xl.ltsuGJQ2xK5ITsIdJhwX5Ggwt3Tcfti', 'yoga', 'admin', '2025-04-04 09:20:51'),
(9, 'faisal', '$2y$10$j/rRPw4TRJ1v8/NpIr58pOZTf9lgApVZDzFwG98700N2QTYrozeGK', 'faisal', 'dasar', '2025-04-04 13:01:51'),
(10, 'yogapras', '$2y$10$wCYwTy3ynpsksiCG8wGldeXmOzQTjWghRKYMd0BXxmE6olU82DkmO', 'yoga pras', 'pelatih', '2025-04-05 09:15:00'),
(11, 'mahesa', '$2y$10$S4QRoZZTAgJslhsgVC4ih.ZNMYY9kOpagfRDliXx13KpnpI67uzTG', 'mahesa', 'user', '2025-04-05 13:13:35'),
(12, 'fadil', '$2y$10$pCN3IRc7pHMPiU4teLpxi.RbKozqifQPdWyYgcIyAWEgVJ69ztRwm', 'fadil', 'privat8', '2025-04-05 14:42:01'),
(13, 'asep', '$2y$10$AlOavWbQ8OksIMNZtXj4aOJQ9ApQKYvLTdlHNXnw2inG/U/oaML8y', 'asep', 'privat12', '2025-04-05 14:45:45');

-- --------------------------------------------------------

--
-- Table structure for table `waktu_pretes`
--

CREATE TABLE `waktu_pretes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `waktu_gaya_dada` time NOT NULL,
  `waktu_gaya_bebas` time NOT NULL,
  `waktu_gaya_kupu_kupu` time NOT NULL,
  `waktu_gaya_punggung` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `waktu_pretes`
--

INSERT INTO `waktu_pretes` (`id`, `user_id`, `tanggal`, `waktu`, `waktu_gaya_dada`, `waktu_gaya_bebas`, `waktu_gaya_kupu_kupu`, `waktu_gaya_punggung`, `created_at`) VALUES
(1, 11, '2025-04-05', '15:00:00', '00:23:25', '00:25:25', '00:22:00', '02:03:24', '2025-04-05 14:21:15');

-- --------------------------------------------------------

--
-- Table structure for table `waktu_pretes2`
--

CREATE TABLE `waktu_pretes2` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `waktu_gaya_dada_100m` time DEFAULT NULL,
  `waktu_gaya_bebas_100m` time DEFAULT NULL,
  `waktu_gaya_kupu_kupu_100m` time DEFAULT NULL,
  `waktu_gaya_punggung_100m` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `waktu_pretes2`
--

INSERT INTO `waktu_pretes2` (`id`, `user_id`, `tanggal`, `waktu`, `waktu_gaya_dada_100m`, `waktu_gaya_bebas_100m`, `waktu_gaya_kupu_kupu_100m`, `waktu_gaya_punggung_100m`, `created_at`) VALUES
(6, 11, '2025-04-06', '11:00:00', '00:23:00', '00:24:00', '00:25:00', '00:27:00', '2025-04-07 03:15:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absenprivat8`
--
ALTER TABLE `absenprivat8`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `absenprivat12`
--
ALTER TABLE `absenprivat12`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `kehadiran2`
--
ALTER TABLE `kehadiran2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pelatih`
--
ALTER TABLE `pelatih`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pembayaran2`
--
ALTER TABLE `pembayaran2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `privat8`
--
ALTER TABLE `privat8`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `privat12`
--
ALTER TABLE `privat12`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `progres`
--
ALTER TABLE `progres`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `progres2`
--
ALTER TABLE `progres2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `waktu_pretes`
--
ALTER TABLE `waktu_pretes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `waktu_pretes2`
--
ALTER TABLE `waktu_pretes2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absenprivat8`
--
ALTER TABLE `absenprivat8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `absenprivat12`
--
ALTER TABLE `absenprivat12`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `kehadiran`
--
ALTER TABLE `kehadiran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kehadiran2`
--
ALTER TABLE `kehadiran2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pelatih`
--
ALTER TABLE `pelatih`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran2`
--
ALTER TABLE `pembayaran2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `privat8`
--
ALTER TABLE `privat8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `privat12`
--
ALTER TABLE `privat12`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `progres`
--
ALTER TABLE `progres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `progres2`
--
ALTER TABLE `progres2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `waktu_pretes`
--
ALTER TABLE `waktu_pretes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `waktu_pretes2`
--
ALTER TABLE `waktu_pretes2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `absenprivat8`
--
ALTER TABLE `absenprivat8`
  ADD CONSTRAINT `absenprivat8_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `absenprivat12`
--
ALTER TABLE `absenprivat12`
  ADD CONSTRAINT `absenprivat12_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD CONSTRAINT `kehadiran_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `kehadiran2`
--
ALTER TABLE `kehadiran2`
  ADD CONSTRAINT `kehadiran2_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pembayaran2`
--
ALTER TABLE `pembayaran2`
  ADD CONSTRAINT `pembayaran2_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `privat8`
--
ALTER TABLE `privat8`
  ADD CONSTRAINT `privat8_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `privat12`
--
ALTER TABLE `privat12`
  ADD CONSTRAINT `privat12_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `progres`
--
ALTER TABLE `progres`
  ADD CONSTRAINT `progres_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `progres2`
--
ALTER TABLE `progres2`
  ADD CONSTRAINT `progres2_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `waktu_pretes`
--
ALTER TABLE `waktu_pretes`
  ADD CONSTRAINT `waktu_pretes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
