<?php
session_start();
include 'config/config.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];

        switch ($user['role']) {
            case 'admin':
                header("Location: views/admin/dashboard.php");
                break;
            case 'pelatih':
                header("Location: views/pelatih/dashboard.php");
                break;
            case 'user':
                header("Location: views/user/dashboard.php");
                break;
            case 'dasar':
                header("Location: views/dasar/dashboard.php");
                break;
            case 'privat8':
                header("Location: views/privat8/dashboard.php");
                break;
            case 'privat12':
                header("Location: views/privat12/dashboard.php");
                break;
            default:
                $error = "Role tidak dikenali!";
                break;
        }
        exit();
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Les Renang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: url('../les_renang/asset/serong.png') no-repeat center center/cover;
            height: 100vh;
        }

        .container-login {
            display: flex;
            height: 100vh;
            backdrop-filter: brightness(0.9);
        }

        .login-form {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            animation: fadeInLeft 1s ease-in-out;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 20px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25);
        }

        .login-card img.logo {
            display: block;
            margin: 0 auto 20px;
            width: 100px;
        }

        .login-card h3 {
            text-align: center;
            color: #0072ff;
            margin-bottom: 25px;
        }

        .form-control {
            background: #f0f0f0;
        }

        .form-control:focus {
            background: #fff;
            border-color: #007bff;
            box-shadow: none;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            font-weight: bold;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .side-image {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            animation: fadeInRight 1s ease-in-out;
            padding: 30px;
        }

        .side-image img {
            max-width: 90%;
            max-height: 90%;
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            object-fit: cover;
        }

        .input-group-text {
            background-color: #f0f0f0;
            cursor: pointer;
        }

        @keyframes fadeInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes fadeInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @media (max-width: 768px) {
            .container-login {
                flex-direction: column;
            }

            .side-image {
                height: 200px;
            }

            .side-image img {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="container-login">
        <div class="login-form">
            <div class="login-card">
                <img src="../les_renang/asset/image_no_white_bg (1).png" alt="Logo Renang" class="logo">
                <h3>Login Les Renang</h3>
                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger text-center"><?= $error; ?></div>
                <?php endif; ?>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Masukkan Username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password" required>
                            <span class="input-group-text" id="togglePassword">
                                <i class="fa-solid fa-eye" id="eyeIcon"></i>
                            </span>
                        </div>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
                </form>
                <p class="text-center mt-3">Belum punya akun? <a href="#">Daftar</a></p>
            </div>
        </div>
        <div class="side-image d-none d-md-flex">
            <img src="../les_renang2/asset/utamihd.png" alt="Latihan Renang">
        </div>
    </div>

    <script>
        const togglePassword = document.getElementById("togglePassword");
        const password = document.getElementById("password");
        const eyeIcon = document.getElementById("eyeIcon");

        togglePassword.addEventListener("click", function() {
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);

            eyeIcon.classList.toggle("fa-eye");
            eyeIcon.classList.toggle("fa-eye-slash");
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>